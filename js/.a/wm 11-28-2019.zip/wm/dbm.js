
/**
 * Между тем, почему свечение невозможно на базовой оси: свет идёт только от третьего элемента.
 *  */

class WDbm extends WGeom {
    constructor (X1=3, add=0, Tau=new THREE.Vector3(500,0,0), YShift=0) {
        super(Tau, YShift)
        this.ISCACHE = {}
        this.X1 = X1
        this.X2 = X1 + add
        this.Mok1 = this.I / (X1 - 1)
        //https://threejs.org/docs/index.html#api/en/Math/Vector3
        // TODO: and, BTW, https://threejs.org/docs/index.html#api/en/Math/Spherical
    }

    /**
     * Returns an angle in the direction of this.T focus
     * @param {Vector3} coord the dot to be measured
     * @param {Vector3} base "Start of the vector"
     */
    angle (coord, base=this.O) {
        let crd = new THREE.Vector3();
        crd.subVectors(coord, base);
        let ret = {
            rad: crd.distanceTo(this.O),
            angle: (coord.z > 0 ? -1 : 1)*crd.angleTo(this.T)}; //case -z- is closer to us, it is negative angle
        return ret
    }
    fromCyl (r, t, h=0) {
        let ret = new THREE.Vector3().setFromCylindricalCoords (r, t, h)
        return ret
    }
    intersection (a, t, neg=false) {
        if (typeof(this.ISCACHE[`${a}:${t}:${neg}`])!='undefined')
            return this.ISCACHE[`${a}:${t}:${neg}`]

        var ret = false;
        let ar = this.Mok1 * a,
            tr = this.Mok1 * t,
            hp = (this.I + ar + tr) / 2;
        if(
            a + t >= this.X1-1 && //in I1
            Math.abs(a - t) < this.X1 //not out of I2
        ) {

            /**
             * L=3; 2;4 => |a-t| = 2; 
             * 
             */

            let hI = 0, x = 0, coef = 1;
            try {hI = (2 * Math.sqrt(hp * (hp - this.I) * (hp - ar) * (hp - tr) ) ) / this.I}
            catch(e) {hI = 0}

            if(isNaN(hI)) hI = 0;

            if (tr >= ar) {
                tr = [ar, ar = tr][0];
                coef = -1;
            }
            let sina = 0;
            if (ar != 0)
                sina = hI / ar;
            let an = Math.asin(sina);
            let sx = ar * Math.cos(an);
            x = coef * (-this.I) / 2 + coef * sx; //correction of the position of adjacent katet
            ret = this.V([x, this.YShift, neg?hI:-hI]); //TODO: REDO UP-DOWN, NOW NEGATIVE IS POSITIVE AND VICE VERSA
        }
        return ret;
    }

    mark_foci () {
        this.dot(this.A, this.DotSize, 'black')
        let dt = this.dot(this.T, this.DotSize, 'white')
        // SS.push(dt)
        // this.dot(this.O, this.DotSize, 'green')
    }
    mark_circle_2d (focus, radius, color='black') {
        this.backupColor()
        this.Color = color;
        let ret = this.circle(focus, radius)
        this.backupColor()
        return ret;
    }
    mark_circles_AT (a, t) {
        let ar = a * this.Mok1, tr = t * this.Mok1
        let ret = []
        ret.push(this.mark_circle_2d(this.A, ar))
        ret.push(this.mark_circle_2d(this.T, tr))
        return ret
    }
    mark_circle_mok1 (n, focus) {
        return this.mark_circle_2d(focus, n * this.Mok1)
    }
    mark_circles_all (third=false) {
        let ret = []
        for (let i=0;i<this.X2;i++) {
            ret.push(this.mark_circle_mok1(i, this.A))
            let CT = this.mark_circle_mok1(i, this.T)
            ret.push(CT)
            // SS.push(CT)
            if (third){
                ret.push(this.mark_circle_mok1(i,
                                               this.intersection(this.X2-1,
                                                                 this.X2-1)))}
        }
        return ret
    }
    mark_circles4wyan (a, t) {
        let ar = a * this.Mok1, tr = t * this.Mok1
        let br = (a-1) * this.Mok1, ur = (t-1) * this.Mok1
        let ret = []
        ret.push(this.mark_circle_2d(this.A, ar))
        ret.push(this.mark_circle_2d(this.A, br))
        ret.push(this.mark_circle_2d(this.T, tr))
        ret.push(this.mark_circle_2d(this.T, ur))
        return ret
    }

    wyan_path (a, t) {
        const _WyanPaths = {
            '4d__': "0- -0 0+ +0", //regular group - in both Is
            'e1I1': "0- -+ +0", //first ellipse groups, going first towards T-focus (A -> T)
            'bAI2': "0- -0 ++", //"+0 0+ --", #no 1e on I2: BA from A out
            'bTI2': "-0 0- ++" //no 1e on I2: BA from T out
            //'3uI1':"",'3uI2':"",'3dI1':"",'3dI2':"",'3rI1':"",'3rI2':"",'3lI1':"",'3lI2':""
        }
        let _pex1c = function (a, t, pathcode) {
            let pa = pathcode.split(" ");
            let path = [[a, t]];
            for (let i=0;i<pa.length;i++) {
                path.push(pa[i]);
                switch (pa[i]) {
                    case "0-": path.push([a,   t-1]);break
                    case "0+": path.push([a,   t+1]);break
                    case "-0": path.push([a-1, t  ]);break
                    case "+0": path.push([a+1, t  ]);break
                    case "-+": path.push([a-1, t+1]);break
                    case "+-": path.push([a+1, t-1]);break
                    case "--": path.push([a-1, t-1]);break
                    case "++": path.push([a+1, t+1]);break
                }
                a = path[path.length-1][0];
                t = path[path.length-1][1];
            }
            return path;
        }
        //
        let pathcode="";
        if (a==0||t==0) { //zeros don't shine
            return false;
        } else { //non-zero dot
            pathcode = _WyanPaths['4d__'];
            if (a+t==this.X1-1) { //BA doesn't shine
                return false;
            } else if (a+t==this.X1) { //first ellipsoid
                pathcode = _WyanPaths['e1I1'];
            } else if (a>=this.X1||t>=this.X1) { //other dots
                let l = Math.min(a, t), h = Math.max(a, t);
                if (h-l<=this.X2-1){ //
                    if(h-l==this.X1-1) { //4: 5-7 -> 2; 
                        if (a>t) {pathcode = _WyanPaths['bTI2']}
                        else {pathcode = _WyanPaths['bAI2']}
                    } else {
                        pathcode = _WyanPaths['4d__'];
                    }
                } else {
                    return false;
                }
            }
            let p = _pex1c(a, t, pathcode);
            return p; //in the form [[a, t], '+0', [a+1, t], ...]
        }

    }
    wyan_pathExists (path) {
        if (!path) return false;
        for (let i=0;i<path.length;i+=2) { //we skip pathfrase item
            let a = path[i][0], t = path[i][1];
            if (!this.intersection(a, t))
                return false;
        }
        return true;
    }
    wyan_vecs (a, t, neg=false) {
        let path = this.wyan_path(a, t)
        if (!path || !this.wyan_pathExists(path)) return []

        let wyan = [], wnam = `Wyan ${a}:${t}:${neg}`
        for (let i=0;i<=path.length-1;i+=2) {
            if (i==path.length-1) break

            let a = path[i][0],
                t = path[i][1]
            let arr = [a, t]
            let pw = path[i+1] //string representation of path step
            let pfr = [...pw]//pw.split("")
            let cwd = true //clockwise direction

            //if T in the pair is not getting lower or A doesn't grow, we write CW
            if (pw == "-0" || pw == "0+") cwd = false
            //"downstairs" draw everything in opposite direction
            if (neg) cwd = !cwd

            for (let c=0;c<pfr.length;c++) {
                if (pfr[c] == '+')
                    arr[c] += 1
                else if (pfr[c] == '-')
                    arr[c] -= 1
            }
            let d0 = this.intersection(a, t, neg)
            let d1 = this.intersection(arr[0], arr[1], neg)

            let index = pfr.indexOf('0')
            let foci = [this.A, this.T]
            let curr = [a, t] //current radius

            // FIXME(Xi): From here to separate function?
            //
            if (index > -1){ //an ark around some focus

                let radius = curr[index] * this.Mok1

                let ar0 = this.angle(d0, foci[index]),
                    ar1 = this.angle(d1, foci[index])

                let name = this.arc(foci[index], f(radius), ar0.angle, ar1.angle, cwd)

                // if(_DEBUG_){CL(`WV: arc ${name}`)}

                this.toGroup(wnam, this.G[name].object)

                // if(_DEBUG_){CL(`WV: after toGroup ${wnam}`)}

                wyan.push(this.G[name].vectors)
            } else { //a line between dots
                let lnnam = this.line(d0, d1)
                this.toGroup(wnam, this.G[lnnam].object)
                wyan.push(this.G[lnnam].vectors)
            }
        }

        this.G[wnam] = {vectors: [].concat.apply([], wyan), vertices: null, object: 'undefined'}
        return wnam
    }

    wyans_all (symbols=WConsts.cWAE_CYR) { //accepts -1 to colorize by indexes only

        let wd = new WDbmSymbols(symbols, 0, this.X1) //IN ORDER TO WORK WITH TEXT WE WILL HAVE TO EXTEND THE CLASS

        for(let i=0;i<dbm.X2;i++){
            for(let j=0;j<dbm.X2;j++){
                let p = dbm.wyan_path(i, j)
                if (dbm.wyan_pathExists(p)) {

                    // let colp = wd.color_by_val(wd.triple_sum(wd.triple_AT(i, j)))
                    // let coln = wd.color_by_val(wd.triple_sum(wd.triple_AT(i, j, true)))

                    // dbm.Draw = false
                    this.backupColor()

                    if (symbols == -1) {
                        let index_color = wd.color_by_index_only(i. j)
                        let wv = null
                        if (i >= j) {
                            wv = dbm.wyan_vecs(i, j)
                        } else { // here we meet some symmetry, so swap i and j
                            wv = dbm.wyan_vecs(wd.MaxIndex - wd.smod(i, wd.MaxIndex), 
                                               wd.MaxIndex - wd.smod(j, wd.MaxIndex), 
                                               true)
                        }
                        // let wm = dbm.mesh(wv, `#${index_color}`)
                    } else if (false) {
                        let tr = wd.triple_AT(i, j), ntr = wd.triple_AT(i, j, true)
                        // let trvp = wd.word_value(tr), trvn = wd.word_value(ntr)
                        let colp0 = wd.color_by_word (tr)
                        let coln0 = wd.color_by_word (ntr)
                        this.Color = `#${colp0}`
                        let wv0p = dbm.wyan_vecs(i, j)
                        this.Color = `#${coln0}`
                        let wv0n = dbm.wyan_vecs(i, j, true)
                        // let wm0p = dbm.mesh(wv0p, `#${colp0}`)
                        // let wm0n = dbm.mesh(wv0n, `#${coln0}`)
                    }
                    // dbm.Draw = true

                    this.backupColor()
                    // this.dot(this.intersection(i, j), this.DotSize*2, `${wd.сolor_invert(colp0, true)}`)
                    // this.dot(this.intersection(i, j, true), this.DotSize*2, `${wd.сolor_invert(coln0, true)}`)
                }
            }
        }
    }

    //https://tympanus.net/codrops/2017/05/09/infinite-tubes-with-three-js/
}

const WLLEN = 5
let wd = new WDbmSymbols(WConsts.cWAE_CYR, 0, WLLEN)
let dbm = new WDbm(WLLEN)
window.D = (pos, col) => dbm.dot(pos, dbm.DotSize*3, col)
window.I = (a, t, neg=false) => dbm.intersection (a, t, neg)


dbm.wyans_all(-1); D(dbm.A, "black"); D(dbm.T, "white")