G._f32x4aToArray = function (f32a) {
  var f32wda = [];
  for (let i=0;i<f32a.length;i++) {
      for (let j=0;j<f32a[i].length;j++) {
          f32wda.push(f32a[i][j]);}}
  return f32wda;
};

G._arr2V2 = function (arr) { //we skip Y-coord
  let ret = [];
  for(let i=0;i<arr.length;i+=3) {
    ret.push(new THREE.Vector2(arr[i], arr[i+2]));
  }
  return ret;
};

G._getRandomColor = function () {
  var letters = '0123456789ABCDEF';
  var color = '#';
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
};

G._AddHebLang = function(start, base_length){ //must be run to start making wyans with adequate color
  abgd.start = start || 0;
  abgd.base_length = base_length || 22;
  if (abgd.start + abgd.base_length > 27)
    throw "Want too much of hebrew: " + start + base_length + " letters!";
  abgd.maxGem = 0;
  // https://uigradients.com/
  abgd.gradient = ['#000000', '#c50106', '#f5f100', '#ffffff'];//['#544a7d', '#ffd452'];//['#1e9600', '#fff200', '#ff0000'];
  abgd.__rs = "abgdhvzxtiklmnsopcqrSTKMNPC".split("");
  abgd.__rl = ["א", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ", "צ", "ק", "ר", "ש", "ת", "ך", "ם", "ן", "ף", "ץ"]
  abgd.__es = ["lP", "iT", "ml", "lT", "i", "v", "in", "iT", "iT", "vd", "P", "md", "iM", "vN", "mK", "iN", "i", "di", "vP", "iS", "iN", "v", "P", "iM", "vN", "i", "di"];//.reverse();
  abgd.__rv = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 200, 300, 400, 500, 600, 700, 800, 900];//.reverse();
  abgd.root_lat = function(index) {
    if (index > -1 && index < abgd.__rs.length) 
      return abgd.__rs[index]
    else
      return false;
  };
  abgd.root_heb = function(index) {
    if (index > -1 && index < abgd.__rl.length) 
      return abgd.__rl[index]
    else
      return false;
  };
  abgd.endg_lat = function(index) {
    if (index > -1 && index < abgd.__es.length) 
      return abgd.__es[index]
    else
      return false;
  };
  abgd.endg_heb = function(index) {
    let e0;
    if (index > -1 && index < abgd.__rs.length) 
      e0 = abgd.__rs[index]
    else
      return false;
    let e1 = e0.split("");
    for (let i=0;i<e1.length;i++) {
      let ndx = abgd.__rs.indexOf(e1[i]);
      if (ndx >= 0) 
        e1[i] = abgd.__rl[ndx]
      else return false;
    }
    let e2 = e1.join("");
    return e2;
  };
  abgd.lval_lat = function (letter) {
    let ndx = abgd.__rs.indexOf(letter);
    if (ndx >= 0) {
      return parseInt(abgd.__rv[ndx]);
    } else return false;
  };
  abgd.lval_heb = function (letter) {
    let ndx = abgd.__rl.indexOf(letter);
    if (ndx >= 0) {
      return parseInt(abgd.__rv[ndx]);
    } else return false;
  };
  abgd.word_gem = function (word) {
    let wd0 = word.split("");
    let ar = abgd.__rl; 
    if (ar.indexOf(wd0[0])==-1) //function thinks, that if the first word is lating, the word is in latin
      ar = abgd.__rs;
    let val = 0;
    for (let i=0;i<wd0.length;i++) {
      let ndx = ar.indexOf(wd0[i]);
      if (ndx >= 0) {
        val += parseInt(abgd.__rv[ndx]);
      } //if the letter not found, just add nothing
    }
    return val;
  };
  abgd.pair_lat = function (a, t) {
    let ret = "";
    if ((a >= 0 && t >= 0) && (a < abgd.__rs.length && t < abgd.__rs.length)) {
      ret = abgd.root_lat(a) + abgd.endg_lat(t);
    }
    return ret;
  };
  abgd.pair_heb = function (a, t) {
    let ret = "";
    if ((a >= 0 && t >= 0) && (a < abgd.__rl.length && t < abgd.__rl.length)) {
      ret = abgd.root_lat(a) + abgd.endg_lat(t);
    }
    return ret;
  };
  abgd.smod = function(num) {
    let path = 0, dir = 1;
    for (let i=0;i<num;i++) {
      if (path==abgd.base_length)
        dir = -1;
      if(path==0)
        dir = 1
      path += dir;
    }
    return path;
  };
  abgd.write = function(text, pos) {
    let loader = new THREE.FontLoader();
    let font = loader.load ("fonts/optimer_bold.typeface.json", 
      function (font) {
        // scene.add(font)
        let tgeo = new THREE.TextGeometry(text, {
          font: font,
          size: 1,
          height: .001,
          curveSegments: 12,
          // bevelEnabled: true,
          // bevelThickness: .1,
          // bevelSize: .1,
          // bevelOffset: 0,
          // bevelSegments: 1
        });
        let tmat = new THREE.MeshPhongMaterial({
          color:0xff0000//abgd.getWordColor()
        });
        const pointLight = new THREE.PointLight(0xffffff, 1.5); 
        pointLight.position.set(0, 100, 90); 
        scene.add(pointLight); 
        pointLight.color.setHSL(Math.random(), 1, 0.5);       
        let tmes = new THREE.Mesh(tgeo, tmat);
        tmes.position.set(pos.x, pos.y, pos.z);
        tmes.rotation.y = Math.PI;
        tmes.rotation.x = Math.PI / 3;
        scene.add(tmes);
      },
      function (xhr) {},
      function (err) {console.log(err)});
  }; //abgd.write("666", new THREE.Vector3(5, 2, 2));
  abgd.write_lat = function (i, j) {
    ;
  };
  abgd.getMax = function () {
    if (abgd.maxGem != 0) return abgd.maxGem;
    let va = true, ndx=abgd.start, max=-1;
    while(va != false) {
      if (ndx >= abgd.start+abgd.base_length) 
        break;
      let w = abgd.endg_lat(ndx++);
      va = abgd.word_gem(w);
      if(va > max) max = va;
    }
    abgd.maxGem = max + abgd.__rv[abgd.base_length-1];
    return abgd.maxGem;
  }; abgd.getMax();
  abgd.getWordColor = function(word) { //word is not the word in itself, only the hebrew letters
    let wg = abgd.word_gem(word);
    let g = GradientGenerator.createGradient(abgd.gradient)
    let c = g.getColorHexAt(1/abgd.getMax()*wg);
    return c;
  };
  abgd.getGemColor = function (gem) {
    if (gem >= abgd.getMax()) return false;
    let g = GradientGenerator.createGradient(abgd.gradient)
    let c = g.getColorHexAt(1/abgd.getMax()*gem);
    return c;
  }
}; G._AddHebLang();

G._flat_wyan = function (a, t) {
  //https://threejs.org/docs/#api/en/extras/curves/CatmullRomCurve3
  //https://threejs.org/docs/#api/en/geometries/ParametricGeometry MAYBE?
  //https://threejs.org/docs/#api/en/extras/curves/SplineCurve
  //https://threejs.org/examples/#webgl_geometry_shapes
  //https://threejs.org/docs/#api/en/geometries/ExtrudeGeometry
  //http://qaru.site/questions/15388378/how-can-i-convert-a-threecatmullromcurve3-to-a-mesh
  let w = G.draw_wyan(a, t, true);
  if (!w) return false;
  let pts = G._arr2V2(G._f32x4aToArray(w));
  let shp = new THREE.Shape();
  shp.moveTo(pts[0].x, pts[0].y);
  shp.autoClose = true;
  for (let i=1;i<pts.length;i++) {
    shp.lineTo(pts[i].x, pts[i].y);
  }
  let gep = new THREE.ExtrudeGeometry(
    shp, 
    {
      steps: 1,
      depth: .1,
      bevelEnabled: true,
      bevelThickness: .1,
      bevelSize: .1,
      bevelSegments: 1
    });
  let emat = new THREE.MeshPhongMaterial( {
    color: abgd.getWordColor(abgd.pair_lat(a, t)), //0x2194ce, 
    // emissive: G._getRandomColor(),// 0x642a2a,
    // specular: 0x6f8be6,
    // wireframe: true,
    flatShading:true,
    side:THREE.DoubleSide, //THREE.DoubleSide, THREE.BackSide
  } );
  let mesh = new THREE.Mesh(gep, emat);
  mesh.rotation.x = math.pi / 2;
  scene.add (mesh);

}

G.Test = function(){
  for (let i=0;i<M._Xer1;i++) {
    for(let j=0;j<M._Xer1;j++) {
      if (G.path_extant_P(G.path(i, j))) {
        // G._flat_wyan(i, j);
        // G._mark_wyan_dots(i, j);
        if (i + j == M._Xer1){
          let en = abgd.root_lat(i) + abgd.endg_lat(j);
          console.log("A", i, "T", j, "wrd:", en);
        }
      }
    }
  }
}; G.Test();
