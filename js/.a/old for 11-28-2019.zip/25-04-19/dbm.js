/*
    //Интересно: https://ru.wikipedia.org/wiki/Матрица_поворота
    //https://ru.wikipedia.org/wiki/Пространственно-временная_диаграмма
    //https://github.com/stemkoski/stemkoski.github.com/tree/master/Three.js
    //https://github.com/stemkoski/stemkoski.github.com/tree/master/Three.js/images
    //https://stemkoski.github.io/Three.js/
    //https://github.com/mrdoob/three.js/

    http://www.threejsgames.com/extensions/

    http://svgdiscovery.com/THREEjs/CSS3D/examples-CSS3D-SVG.htm (SEEN.JS)

    //https://free3d.com/

    //https://jtiscione.github.io/chessboard3js/docs.html
    //https://github.com/SuperiorJT/Threejs-Chess

    //https://habr.com/ru/post/436482/ - шейдерные материалы и постобработка
*/
var scene, camera, renderer, axesHelper, OrbitControls, resizer, light, lightbulb, skyBox, INTERSECTED, raycaster /* look on raycasting here https://threejs.org/examples/#webgl_raycast_texture */,mouse, parameters, sphere, cube, sph1, sph2, slight, slightHelper, dragObjs=[] /* https://keqingrong.github.io/three-dragger/example/ */,cssScene, rendererCSS, resizerCss, mixerContext;

function posSetEqual(obj1, obj2) {
    obj1.position.set(obj2.position.x, obj2.position.y, obj2.position.z);
}
function MAIN (){
    // Converts from degrees to radians.
    math.radians = function(degrees) {
        return degrees * math.PI / 180;
    };
    // Converts from radians to degrees.
    math.degrees = function(radians) {
        return radians * 180 / math.PI;
    };
    (function basicSetup() {
        scene = new THREE.Scene();

        //on group camera rotation - https://stackoverflow.com/questions/50060423/three-js-rotate-camera-separately-from-its-parent?rq=1
        camera = new THREE.PerspectiveCamera( 45, window.innerWidth/window.innerHeight, 0.1, 10000 );

        renderer = new THREE.WebGLRenderer({alpha:true});
        // document.getElementsByTagName('canvas').set('nomen', 'Orig');
        // .getElementById("myElement").myProperty = "my value"; (https://stackoverflow.com/questions/4258466/can-i-add-arbitrary-properties-to-dom-objects)

        renderer.setClearColor(new THREE.Color('black'), 0)

        renderer.setPixelRatio( window.devicePixelRatio );
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFShadowMap;
        renderer.setSize( window.innerWidth, window.innerHeight );

        axesHelper = new THREE.AxesHelper(10);
        scene.add( axesHelper );

        resizer = new THREEx.WindowResize( renderer, camera );
        document.body.appendChild( renderer.domElement );
        camera.position.set(0, 60, -10);
        // camera.rotation.x = math.radians(60);
        // camera.matrix.fromArray(JSON.parse(
            // from JSON.stringify(camera.matrix.toArray())
            //and still doesn't work (((
                // "[0.9990026142855373,3.469446951953614e-18,0.04465172617785408,0,0.044651726177831745,0.0000010001554604510685,-0.9990026142850376,0,-4.465866775688054e-8,0.9999999999994998,9.991579197343723e-7,0,0.41827075941864145,100.90216614733063,0.5191194457329098,1]"
        // ));
        // camera.matrix.decompose(camera.position, camera.quaternion, camera.scale);

        OrbitControls = new THREE.OrbitControls(camera);

        raycaster = new THREE.Raycaster();
        mouse = new THREE.Vector2();
        function onMouseMove( event ) {
            // calculate mouse position in normalized device coordinates
            // (-1 to +1) for both components
            mouse.x = ( event.clientX / window.innerWidth ) * 2 - 1;
            mouse.y = - ( event.clientY / window.innerHeight ) * 2 + 1;
        }
        window.addEventListener( 'mousemove', onMouseMove, false );

        function animate () {
            requestAnimationFrame( animate );

            /** TODO: RAYCASTER DOESN'T WORK! //update the picking ray with the camera and mouse position
            raycaster.setFromCamera( mouse, camera ); (function fnIntersect() {
            // https://github.com/mrdoob/three.js/issues/1934 *
            const insterss = raycaster.intersectObjects( scene.children );
            for (var i=0;i<insterss.length; i++) {}})();*/

            OrbitControls.update();

            // mixerContext.update(); // - TODO:uncomment this, if need a css-renderer
            renderer.render( scene, camera );
        };
        animate();
    })();
    (function grids(size=50, step=10){
        //GRID
        var gridXZ = new THREE.GridHelper(size, step, colorCenterLine=new THREE.Color(0x006600), colorGrid=new THREE.Color(0x006600));
        gridXZ.position.set( 25,-15,25 );
        scene.add(gridXZ);
        var gridXY = new THREE.GridHelper(size, step, colorCenterLine=new THREE.Color(0x000066), colorGrid=new THREE.Color(0x000066));
        gridXY.position.set( 25,25,-15 );
        gridXY.rotation.x = math.PI/2;
        scene.add(gridXY);
        var gridYZ = new THREE.GridHelper(size, step, colorCenterLine=new THREE.Color(0x660000), colorGrid=new THREE.Color(0x660000));
        gridYZ.position.set( -15,25,25 );
        gridYZ.rotation.z = math.PI/2;
        scene.add(gridYZ);
    });//();
    (function skybox(){
        // SKYBOX
        var skyBoxGeometry = new THREE.BoxGeometry( 2000, 2000, 2000 );
        var skyBoxMaterial = new THREE.MeshBasicMaterial( { color: 0xaaaaaa, side: THREE.BackSide } );
        skyBox = new THREE.Mesh( skyBoxGeometry, skyBoxMaterial );
        scene.add(skyBox);
        ////////EITHER SKYBOX OR FOG
        //FOG
        // scene.fog = new THREE.FogExp2( 0x335566, 0.01);//0.00025 );
    })();
    (function lightSetup(){
        // general light
        var ambientLight = new THREE.AmbientLight(0xffffff);
        scene.add(ambientLight);
        // light to see some volume
        light = new THREE.PointLight(0xffff00);
        light.position.set(-20,15,-3);
        scene.add(light);
        //#####################################################################################
        /*  //lightbulb
            var lightbulbGeometry = new THREE.SphereGeometry( 3, 8, 8 );
            var lightbulbMaterial = new THREE.MeshBasicMaterial( { color: 0xffffff, transparent: true,  opacity: 0.9, blending: THREE.AdditiveBlending } );
            var wireMaterial = new THREE.MeshBasicMaterial( { color: 0x000000, wireframe: true } );
            var materialArray = [lightbulbMaterial, wireMaterial];
            lightbulb = THREE.SceneUtils.createMultiMaterialObject( lightbulbGeometry, materialArray );
            posSetEqual(lightbulb, light);
            scene.add(lightbulb);
            //#####################################################################################
            var slight = new THREE.SpotLight( 0x441188, .9 );
            slight.position.set( 65, 90, 10 );
            slight.angle = math.PI / 9;
            slight.castShadow = true;
            slight.shadow.camera.near = 1000;
            slight.shadow.camera.far = 4000;
            slight.shadow.mapSize.width = 1024;
            slight.shadow.mapSize.height = 1024;
            scene.add( slight );
        */
        //#####################################################################################
        // var slightHelper = new THREE.SpotLightHelper( slight );
        // scene.add(slightHelper);
    })();
    (function baseSetup(){
        //BASE
        if (false) {
            planeGeo = new THREE.PlaneGeometry(32,32);
            planeMat = new THREE.MeshBasicMaterial({color:0xbbbbbb, opacity:.8, transparent: true});
            basePlane = new THREE.Mesh(planeGeo, planeMat);
            basePlane.rotation.x = -math.PI / 2;
            basePlane.position.set(9,-5,9);
            basePlane.base = true;
            scene.add(basePlane);
            //} else {
            function mipmap( size, color ) {

                var imageCanvas = document.createElement( "canvas" ),
                    context = imageCanvas.getContext( "2d" );

                imageCanvas.width = imageCanvas.height = size;

                context.fillStyle = "#444";
                context.fillRect( 0, 0, size, size );

                context.fillStyle = color;
                context.fillRect( 0, 0, size / 2, size / 2 );
                context.fillRect( size / 2, size / 2, size / 2, size / 2 );
                return imageCanvas;

            }

            var canvas = mipmap( 128, '#f00' );
            var textureCanvas1 = new THREE.CanvasTexture( canvas );
            textureCanvas1.mipmaps[ 0 ] = canvas;
            textureCanvas1.mipmaps[ 1 ] = mipmap( 64, '#0f0' );
            textureCanvas1.mipmaps[ 2 ] = mipmap( 32, '#00f' );
            textureCanvas1.mipmaps[ 3 ] = mipmap( 16, '#400' );
            textureCanvas1.mipmaps[ 4 ] = mipmap( 8, '#040' );
            textureCanvas1.mipmaps[ 5 ] = mipmap( 4, '#004' );
            textureCanvas1.mipmaps[ 6 ] = mipmap( 2, '#044' );
            textureCanvas1.mipmaps[ 7 ] = mipmap( 1, '#404' );
            textureCanvas1.repeat.set( 1000, 1000);
            textureCanvas1.wrapS = THREE.RepeatWrapping;
            textureCanvas1.wrapT = THREE.RepeatWrapping;

            var materialCanvas1 = new THREE.MeshBasicMaterial( { map: textureCanvas1 } );

            var geometry = new THREE.PlaneBufferGeometry( 100, 100 );

            var meshCanvas1 = new THREE.Mesh( geometry, materialCanvas1 );
            meshCanvas1.rotation.x = - math.PI / 2;
            meshCanvas1.position.y -= 56
            meshCanvas1.scale.set( 100, 100, 100 );

            scene.add( meshCanvas1 );
        } else {
            ;
        }
    })();
};

M = MAIN; M.G = function () {};

M._dbmInit = function (I=100, Xer1=22) {
    if (true) {
        M._I = I;
        M._Xer1 = Xer1;
        M._Mok1 = I / (Xer1 - 1);
        M._Na = 6;
        M._CaMo = 2 * math.PI / M._Na; //part of angle for one step
        //https://threejs.org/docs/index.html#api/en/math/Vector3
        // TODO: and, BTW, https://threejs.org/docs/index.html#api/en/math/Spherical
        M._A =      new THREE.Vector3(-I/2, 0, 0);
        M._T =      new THREE.Vector3( I/2, 0, 0);
        M._Norm =   new THREE.Vector3(0,    1, 0);
        M._O =      new THREE.Vector3(0,    0, 0);
        M._V = function (arr) {
            var r = new THREE.Vector3();
            r.fromArray(arr);
            return r;
        }
        M._Dot(M._A, rad=2, col='black');
        M._Dot(M._T, rad=2, col='white');

        if (false) {
            for (let i=0;i<M._Xer1;i++) {
                let na = M._Na;
                M._Na = 56;
                M._EllArc(M._A, hAxs=[M._Mok1 * i, M._Mok1 * i]);
                M._EllArc(M._T, hAxs=[M._Mok1 * i, M._Mok1 * i]);
                M._Na = na;
                for(let j=0;j<M._Xer1;j++) {
                    let res = M._InSect(i, j);
                    if (typeof(res) != 'undefined') {
                        M._Dot(res);
                    }
                }
            }    
        }
    }
};

function fnGeom(){

    function f(a) {return[a,a]};

    M._Name = function (arr, pref) {
        return pref + arr.join("_");
    };

    /**
     * Inversion: (i, j) => (i / (i ** 2 + j ** 2), j / (i ** 2 + j ** 2)); c => 1/c.conj
     */
    M._InSect = function (a, t, neg=false) {
        var ret = false;
        if (typeof(M._I) == 'undefined')
            M._dbmInit();
        let ar = M._Mok1 * a,
            tr = M._Mok1 * t,
            hp = (M._I + ar + tr) / 2;
        if (a + t >= M._Xer1 - 1){
            let hI = 0, x = 0, coef = 1;
            try {hI = (2 * math.sqrt(hp * (hp - M._I) * (hp - ar) * (hp - tr) ) ) / M._I}
            catch(e) {;}
            if (tr >= ar) {
                tr = [ar, ar = tr][0]
                coef = -1;
            }
            let sina = 0;
            if (ar != 0)
                sina = hI / ar;
            an = math.asin(sina);
            let sx = ar * math.cos(an);
            x = coef * (-M._I) / 2 + coef * sx; //correction of the position of adjacent katet
            ret = M._V([x, 0, neg?-hI:hI]);
        }
        return ret;
    };

    M._IAngle = function (coord, focus) {
        let crd = new THREE.Vector3(); crd.subVectors(coord, focus);
        return {rad: crd.distanceTo(M._O), angle: crd.angleTo(M._T)};
    };

    M._Line = function (vs, ve, onlyDots=false, col=0x110faa, lw=15) {
        let lmat = new THREE.LineBasicMaterial ({color:col, linewidth:lw});
        let lgeo = new THREE.BufferGeometry();
        let verts = [vs.x, vs.y, vs.z, ve.x, ve.y, ve.z];
        let parr = new Float32Array(verts);
        if (!onlyDots) {
            lgeo.addAttribute ('position', new THREE.BufferAttribute (parr, 3));
            let line = new THREE.Line(lgeo, lmat);
            line.castShadow = true;
            scene.add(line);
        }
        return verts;
    };

    M._EllArc = function (vCenter, hAxs=[10, 10], 
        aS=-math.PI, aE=-math.PI*2, 
        onlyDots=false, 
        col=0x00ffff, lw=15, 
        ) {
        function ex (ang, a=hAxs[0]) {return a * math.cos(ang)}
        function ez (ang, b=hAxs[1]) {return b * math.sin(ang)}
        let verts = new Float32Array((M._Na+1) * 3);
        let way = aE - aS;
        let step = way / M._Na;
        for (let i=0;i<=M._Na;i++) {
            verts[i*3  ] = ex(i * step + aS)    + vCenter.x;
            verts[i*3+1] = 0                    + vCenter.y;
            verts[i*3+2] = ez(i * step + aS)    + vCenter.z;
        }
        let parr = new Float32Array(verts);
        if (onlyDots == false) {
            let lmat = new THREE.LineBasicMaterial ({color:col, linewidth:lw, transparent:true, opacity:1});
            let lgeo = new THREE.BufferGeometry();
            lgeo.addAttribute ('position', new THREE.BufferAttribute (parr, 3));
            let line = new THREE.Line(lgeo, lmat);
            line.castShadow = true;
            scene.add(line);
        }
        return verts;
    };

    M._Arc = function (d0, d1, focus, onlyDots=false) {
        let ar0 = M._IAngle(d0, focus), 
            ar1 = M._IAngle(d1, focus);
        // console.log(onlyDots);
        let ret = M._EllArc(focus, hAxs=f(ar0.rad), 
            aS=ar0.angle, aE=ar1.angle, 
            onlyDots=onlyDots);
        return ret;
    }

    M._Dot = function (vDot, rad=.5, col=0xce21a5) { //accepts InSect of Vector3
        if (!vDot) return;
        let sgeo = new THREE.SphereBufferGeometry (rad, 13, 17);
        let smat = new THREE.MeshPhongMaterial ({
            color:col,
            shininess:75,
            // flatShading:true,
            // transparent:true,
            // opacity:.75,
            depthTest:true,
            // side:THREE.FrontSide
        });
        let sph = new THREE.Mesh(sgeo, smat);
        sph.castShadow = true;
        sph.position.set(vDot.x, vDot.y, vDot.z)
        scene.add(sph);
    };

    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////

    M.Wave = {}; M.Wave.graph = function () {
        let W = M.Wave;
        W.wPERIOD =          3;//wave length coefficient
        W.wRANGE =           13;//quantity of loops
        W.wRRUN =            4;//within how many loops the radius changes from min to max or backwards
        W.wSHEER_FACTOR =    .5;
        W.wCIRCLE =          360;//number of degrees in a loop
        W.wRADIUS =          2;//just the radius of a wave
        W.wZSHIFT =          .005;
        /** sheer polarization is governed by the radius of ellipse at the given point
         * всё есть здесь: https://ru.wikipedia.org/wiki/Эллипс
         * r = (_BHA * _LHA) / sqrt(_LHA* *2 * cos(radians(BHA_Point_angle))** 2 + _BHA** 2 * sin(radians(BHA_Point_angle))**2)
         * or:  excentricity = sqrt(1 - _LHA* *2 / _BHA**2)
         * r = _LHA / sqrt(1 - excentricity* *2 * cos(BHA_Point_angle)**2)
         */
        W.wELLIPSE =            1;//0: ellipse, 1: ellipse + z-running r-shift, 2: z-running r-shift
        W.wBHA =                W.wRADIUS;
        W.wLHA =                W.wRADIUS / 2;
        W.wEANGLE =             W.wCIRCLE / 12;//angle of the _BHA inclination
        W.wROTEAN =             false;//rotate _EANGLE by the _CIRCLE/_RANGE part for each iteration. Experimental, has explicable rips
        let res =               [];
        let rfactor =           -1;
        let sfactor =           (r) => {return (r / W.wSHEER_FACTOR) / W.wCIRCLE};//sheer factor
        let r =                 W.wRADIUS;
        let bha =               W.wBHA;
        let lha =               W.wLHA;
        let rng =               math.round(W.wCIRCLE * W.wRANGE);
        let elrad =             (b, l, phi) => {return ((b * l) / math.sqrt(l**2 * math.cos(phi)**2 + b**2 * math.sin(phi)**2))};
        for (let angle=0;angle<rng;angle++) {
            let aa = W.wROTEAN % W.wCIRCLE;
            let BHA_Point_angle = aa - W.wEANGLE;
            if (W.wROTEAN) {
                if (aa == 0) {
                    W.wEANGLE = W.wEANGLE + (W.wCIRCLE / W.wRANGE);
                }
            }
            if (W.wELLIPSE == 0) {//try elliptical polarization
                r = elrad(W.wBHA, W.wLHA, BHA_Point_angle);
            } else if (W.wELLIPSE == 1) {//try'em both
                if (angle % (W.wCIRCLE * W.wRRUN) == 0) {
                    rfactor = -rfactor;
                }
                bha = bha + rfactor * sfactor(W.wBHA);
                lha = lha + rfactor * sfactor(W.wLHA);
                r = elrad(bha, lha, BHA_Point_angle);
            } else if (W.wELLIPSE == 2) {//try just changing radius for several cycles, TODO: may be joined to the elliptical polarization
                if (angle % (W.wCIRCLE * W.wRRUN) == 0) {
                    rfactor = -rfactor;
                }
                r = r + rfactor * sfactor (W.wRADIUS);
            } else {
                ;//static radius
            }
            let c0 = r * math.exp (math.complex(0, math.radians(aa)));
            let time = W.wPERIOD / W.wCIRCLE * angle;
            let p0 = [math.re(c0), math.im(c0), time];
            res.push(p0)
        }
        return res;
    }

    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
};

function fnGroup () {

    M.G.path_extant_P = function (pex1th) {
        if (!pex1th) return false;
        for (let i=0;i<pex1th.length;i+=2) { //we skip pathfrase item
            let a = pex1th[i][0], t = pex1th[i][1];
            if (!M._InSect(a, t))
                return false;
        }
        return true;
    };

    M.G.wyan_points = function (path, onlyDots=false) { //returns array of 4 Float32Arrays
        if (!M.G.path_extant_P(path)) return false;
        let wyan = [];
        for (let i=0;i<=path.length-1;i+=2) {
            if (i==path.length-1) {break}
            let a = path[i][0], 
                t = path[i][1];
            let d0 = M._InSect(a, t)
            let arr = [a, t];
            pfr = path[i+1].split("");
            for (let c=0;c<pfr.length;c++) {
                if (pfr[c] == '+')
                    arr[c] += 1;
                else if (pfr[c] == '-')
                    arr[c] -= 1;
            }
            let d1 = M._InSect(arr[0], arr[1]);
            let index = pfr.indexOf('0');
            let foci = [M._A, M._T];
            if (index > -1){
                let arc = M._Arc(d0, d1, foci[index], onlyDots=onlyDots);
                wyan.push(arc);
            } else {
                let ln = M._Line(d0, d1, onlyDots=onlyDots);
                wyan.push(ln);
            }
        }
        return wyan;
    };

    M.G.path = function (a, t) { //the form [[a, t], '+0', [a+1, t], ...]
        M.G.PathConsts = {
            // 0 doesn't shine
            '4d__': "0- -0 0+ +0", //regular group - in both Is
            // e1 shines (connects to closests on bA), on I1 1e-dots are w/out grandchildren (He-sofits)
            'e1I1': "0- -+ +0", //first ellipse groups, going first towards T-focus (A -> T)
            // e1 out of I1 becomes BA, which can be traced geometrically, joining dots of 1eI1 and
            // continuing the lines bsmoothily to out-of-I1BA (or towards vA). Note that 1e, going BA, divides by direction
            'bAI2': "0- -0 ++", //"+0 0+ --", #no 1e on I2: BA from A out
            'bTI2': "-0 0- ++", //no 1e on I2: BA from T out
            //TODO: write functions for smoothing lines - between angles between dots of arcs
            '3uI1':"",'3uI2':"",'3dI1':"",'3dI2':"",'3rI1':"",'3rI2':"",'3lI1':"",'3lI2':""
        };

        M.G.pex1th = function (a, t, pathcode) {
            let pa = pathcode.split(" ");
            let path = [[a, t]];
            for (let i=0;i<pa.length;i++) {
                path.push(pa[i]);
                switch (pa[i]) {
                    case "0-": path.push([a,   t-1]);break;
                    case "0+": path.push([a,   t+1]);break;
                    case "-0": path.push([a-1, t  ]);break;
                    case "+0": path.push([a+1, t  ]);break;
                    case "-+": path.push([a-1, t+1]);break;
                    case "+-": path.push([a+1, t-1]);break;
                    case "--": path.push([a-1, t-1]);break;
                    case "++": path.push([a+1, t+1]);break;
                }
                a = path[path.length-1][0];
                t = path[path.length-1][1];
            }
            return path;
        };

        let path="";
        if (a==0||t==0) {
            return false;
        } else {
            path = M.G.PathConsts['4d__'];
            if (a+t==M._Xer1-1) {
                return false;
            } else if (a+t==M._Xer1) {
                path = M.G.PathConsts['e1I1'];
            } else if (a>=M._Xer1||t>=M._Xer1) {
                let l = math.min([a, t]), h = math.max([a, t]);
                if (h-l<=M._Xer1-1){
                    if(h-1==M._Xer1-1) {
                        if (a>t) {path = M.G.PathConsts['bTI2']}
                        else {path = M.G.PathConsts['bAI2']}
                    } else {
                        path = M.G.PathConsts['4d__'];
                    }
                } else {
                    return false;
                }
            }
            let p = M.G.pex1th(a, t, path);
            return p; //in the form [[a, t], '+0', [a+1, t], ...]
        }
    };

    M.G.draw_wyan = function (a, t, onlyDots=false) { //draws if od=false; returns array of 4 Float32Arrays
        return M.G.wyan_points(M.G.path(a, t), onlyDots=onlyDots)
    };

    M.G._mark_wyan_dots = function (a, t) {
        let path = M.G.path(a, t);
        if(M.G.path_extant_P(path)) {
            for (let i=0;i<path.length;i+=2) { //we skip pathfrase item
                let a = path[i][0], t = path[i][1];
                M._Dot(M._InSect(a, t));
            }
        } else return false;
    };
}
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

MAIN(); 
fnGeom(); 
fnGroup();
G = M.G;
M._dbmInit();
