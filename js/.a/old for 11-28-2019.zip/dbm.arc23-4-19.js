/*
    //Интересно: https://ru.wikipedia.org/wiki/Матрица_поворота
    //https://ru.wikipedia.org/wiki/Пространственно-временная_диаграмма
    //https://github.com/stemkoski/stemkoski.github.com/tree/master/Three.js
    //https://github.com/stemkoski/stemkoski.github.com/tree/master/Three.js/images
    //https://stemkoski.github.io/Three.js/
    //https://github.com/mrdoob/three.js/

    http://www.threejsgames.com/extensions/

    http://svgdiscovery.com/THREEjs/CSS3D/examples-CSS3D-SVG.htm (SEEN.JS)

    //https://free3d.com/

    //https://jtiscione.github.io/chessboard3js/docs.html
    //https://github.com/SuperiorJT/Threejs-Chess

    //https://habr.com/ru/post/436482/ - шейдерные материалы и постобработка
*/
var scene, camera, renderer, axesHelper, OrbitControls, resizer, light, lightbulb, skyBox, INTERSECTED, raycaster /* look on raycasting here https://threejs.org/examples/#webgl_raycast_texture */,mouse, parameters, sphere, cube, sph1, sph2, slight, slightHelper, dragObjs=[] /* https://keqingrong.github.io/three-dragger/example/ */,cssScene, rendererCSS, resizerCss, mixerContext;

function posSetEqual(obj1, obj2) {
    obj1.position.set(obj2.position.x, obj2.position.y, obj2.position.z);
}
function MAIN (){
    // Converts from degrees to radians.
    math.radians = function(degrees) {
        return degrees * math.PI / 180;
    };
    // Converts from radians to degrees.
    math.degrees = function(radians) {
        return radians * 180 / math.PI;
    };
    (function basicSetup() {
        scene = new THREE.Scene();

        //on group camera rotation - https://stackoverflow.com/questions/50060423/three-js-rotate-camera-separately-from-its-parent?rq=1
        camera = new THREE.PerspectiveCamera( 45, window.innerWidth/window.innerHeight, 0.1, 10000 );

        renderer = new THREE.WebGLRenderer({alpha:true});
        // document.getElementsByTagName('canvas').set('nomen', 'Orig');
        // .getElementById("myElement").myProperty = "my value"; (https://stackoverflow.com/questions/4258466/can-i-add-arbitrary-properties-to-dom-objects)

        renderer.setClearColor(new THREE.Color('black'), 0)

        renderer.setPixelRatio( window.devicePixelRatio );
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFShadowMap;
        renderer.setSize( window.innerWidth, window.innerHeight );

        axesHelper = new THREE.AxesHelper(10);
        scene.add( axesHelper );

        resizer = new THREEx.WindowResize( renderer, camera );
        document.body.appendChild( renderer.domElement );
        camera.matrix.fromArray(JSON.parse(
            // from JSON.stringify(camera.matrix.toArray())
            //and still doesn't work (((
                "[0.9990026142855373,3.469446951953614e-18,0.04465172617785408,0,0.044651726177831745,0.0000010001554604510685,-0.9990026142850376,0,-4.465866775688054e-8,0.9999999999994998,9.991579197343723e-7,0,0.41827075941864145,100.90216614733063,0.5191194457329098,1]"
        ));
        camera.matrix.decompose(camera.position, camera.quaternion, camera.scale);

        OrbitControls = new THREE.OrbitControls(camera);

        raycaster = new THREE.Raycaster();
        mouse = new THREE.Vector2();
        function onMouseMove( event ) {
            // calculate mouse position in normalized device coordinates
            // (-1 to +1) for both components
            mouse.x = ( event.clientX / window.innerWidth ) * 2 - 1;
            mouse.y = - ( event.clientY / window.innerHeight ) * 2 + 1;
        }
        window.addEventListener( 'mousemove', onMouseMove, false );

        function animate () {
            requestAnimationFrame( animate );

            /** TODO: RAYCASTER DOESN'T WORK! //update the picking ray with the camera and mouse position
            raycaster.setFromCamera( mouse, camera ); (function fnIntersect() {
            // https://github.com/mrdoob/three.js/issues/1934 *
            const insterss = raycaster.intersectObjects( scene.children );
            for (var i=0;i<insterss.length; i++) {}})();*/

            OrbitControls.update();

            // mixerContext.update(); // - TODO:uncomment this, if need a css-renderer
            renderer.render( scene, camera );
        };
        animate();
    })();
    (function grids(size=50, step=10){
        //GRID
        var gridXZ = new THREE.GridHelper(size, step, colorCenterLine=new THREE.Color(0x006600), colorGrid=new THREE.Color(0x006600));
        gridXZ.position.set( 25,-15,25 );
        scene.add(gridXZ);
        var gridXY = new THREE.GridHelper(size, step, colorCenterLine=new THREE.Color(0x000066), colorGrid=new THREE.Color(0x000066));
        gridXY.position.set( 25,25,-15 );
        gridXY.rotation.x = math.PI/2;
        scene.add(gridXY);
        var gridYZ = new THREE.GridHelper(size, step, colorCenterLine=new THREE.Color(0x660000), colorGrid=new THREE.Color(0x660000));
        gridYZ.position.set( -15,25,25 );
        gridYZ.rotation.z = math.PI/2;
        scene.add(gridYZ);
    });//();
    (function skybox(){
        // SKYBOX
        var skyBoxGeometry = new THREE.BoxGeometry( 2000, 2000, 2000 );
        var skyBoxMaterial = new THREE.MeshBasicMaterial( { color: 0xaaaaaa, side: THREE.BackSide } );
        skyBox = new THREE.Mesh( skyBoxGeometry, skyBoxMaterial );
        scene.add(skyBox);
        ////////EITHER SKYBOX OR FOG
        //FOG
        // scene.fog = new THREE.FogExp2( 0x335566, 0.01);//0.00025 );
    })();
    (function lightSetup(){
        // general light
        var ambientLight = new THREE.AmbientLight(0xffffff);
        scene.add(ambientLight);
        // light to see some volume
        light = new THREE.PointLight(0xffff00);
        light.position.set(-20,15,-3);
        scene.add(light);
        //#####################################################################################
        /*  //lightbulb
            var lightbulbGeometry = new THREE.SphereGeometry( 3, 8, 8 );
            var lightbulbMaterial = new THREE.MeshBasicMaterial( { color: 0xffffff, transparent: true,  opacity: 0.9, blending: THREE.AdditiveBlending } );
            var wireMaterial = new THREE.MeshBasicMaterial( { color: 0x000000, wireframe: true } );
            var materialArray = [lightbulbMaterial, wireMaterial];
            lightbulb = THREE.SceneUtils.createMultiMaterialObject( lightbulbGeometry, materialArray );
            posSetEqual(lightbulb, light);
            scene.add(lightbulb);
            //#####################################################################################
            var slight = new THREE.SpotLight( 0x441188, .9 );
            slight.position.set( 65, 90, 10 );
            slight.angle = math.PI / 9;
            slight.castShadow = true;
            slight.shadow.camera.near = 1000;
            slight.shadow.camera.far = 4000;
            slight.shadow.mapSize.width = 1024;
            slight.shadow.mapSize.height = 1024;
            scene.add( slight );
        */
        //#####################################################################################
        // var slightHelper = new THREE.SpotLightHelper( slight );
        // scene.add(slightHelper);
    })();
    (function baseSetup(){
        //BASE
        if (false) {
            planeGeo = new THREE.PlaneGeometry(32,32);
            planeMat = new THREE.MeshBasicMaterial({color:0xbbbbbb, opacity:.8, transparent: true});
            basePlane = new THREE.Mesh(planeGeo, planeMat);
            basePlane.rotation.x = -math.PI / 2;
            basePlane.position.set(9,-5,9);
            basePlane.base = true;
            scene.add(basePlane);
            //} else {
            function mipmap( size, color ) {

                var imageCanvas = document.createElement( "canvas" ),
                    context = imageCanvas.getContext( "2d" );

                imageCanvas.width = imageCanvas.height = size;

                context.fillStyle = "#444";
                context.fillRect( 0, 0, size, size );

                context.fillStyle = color;
                context.fillRect( 0, 0, size / 2, size / 2 );
                context.fillRect( size / 2, size / 2, size / 2, size / 2 );
                return imageCanvas;

            }

            var canvas = mipmap( 128, '#f00' );
            var textureCanvas1 = new THREE.CanvasTexture( canvas );
            textureCanvas1.mipmaps[ 0 ] = canvas;
            textureCanvas1.mipmaps[ 1 ] = mipmap( 64, '#0f0' );
            textureCanvas1.mipmaps[ 2 ] = mipmap( 32, '#00f' );
            textureCanvas1.mipmaps[ 3 ] = mipmap( 16, '#400' );
            textureCanvas1.mipmaps[ 4 ] = mipmap( 8, '#040' );
            textureCanvas1.mipmaps[ 5 ] = mipmap( 4, '#004' );
            textureCanvas1.mipmaps[ 6 ] = mipmap( 2, '#044' );
            textureCanvas1.mipmaps[ 7 ] = mipmap( 1, '#404' );
            textureCanvas1.repeat.set( 1000, 1000);
            textureCanvas1.wrapS = THREE.RepeatWrapping;
            textureCanvas1.wrapT = THREE.RepeatWrapping;

            var materialCanvas1 = new THREE.MeshBasicMaterial( { map: textureCanvas1 } );

            var geometry = new THREE.PlaneBufferGeometry( 100, 100 );

            var meshCanvas1 = new THREE.Mesh( geometry, materialCanvas1 );
            meshCanvas1.rotation.x = - math.PI / 2;
            meshCanvas1.position.y -= 56
            meshCanvas1.scale.set( 100, 100, 100 );

            scene.add( meshCanvas1 );
        } else {
            ;
        }
    })();
}; MAIN();

(function fnGeom(){
    M = MAIN;

    function f(a) {return[a,a]};

    M._dbmInit = function (I=100, Xer1=22) {
        M._I = I;
        M._Xer1 = Xer1;
        M._Mok1 = I / (Xer1 - 1);
        M._Na = 11;
        M._CaMo = 2 * math.PI / M._Na; //part of angle for one step
        //https://threejs.org/docs/index.html#api/en/math/Vector3
        // TODO: and, BTW, https://threejs.org/docs/index.html#api/en/math/Spherical
        M._A =      new THREE.Vector3(-I/2, 0, 0);
        M._T =      new THREE.Vector3( I/2, 0, 0);
        M._Norm =   new THREE.Vector3(0,    1, 0);
        M._O =      new THREE.Vector3(0,    0, 0);
        M._V = function (arr) {
            var r = new THREE.Vector3();
            r.fromArray(arr);
            return r;
        }
    }; M._dbmInit();

    M._InSect = function (a, t, neg=false) {
        var ret = false;
        if (typeof(M._I) == 'undefined')
            M._dbmInit();
        let ar = M._Mok1 * a,
            tr = M._Mok1 * t,
            hp = (M._I + ar + tr) / 2;
        if (a + t >= M._Xer1 - 1){
            let hI = 0, x = 0, coef = 1;
            try {hI = (2 * math.sqrt(hp * (hp - M._I) * (hp - ar) * (hp - tr) ) ) / M._I}
            catch(e) {;}
            if (tr >= ar) {
                tr = [ar, ar = tr][0]
                coef = -1;
            }
            let sina = 0;
            if (ar != 0)
                sina = hI / ar;
            an = math.asin(sina);
            let sx = ar * math.cos(an);
            x = coef * (-M._I) / 2 + coef * sx; //correction of the position of adjacent katet
            ret = M._V([x, 0, neg?-hI:hI]);
        }
        return ret;
    };

    M._IAngle = function (coord, focus) {
        let crd = new THREE.Vector3(); crd.subVectors(coord, focus);
        return {rad: crd.distanceTo(M._O), angle: -crd.angleTo(M._T)};
    };

    M._rotate = function (Vec, Axis=M._Norm, Angle=math.PI){
        let v = Vec.clone();
        v.applyAxisAngle(Axis.normalize(), Angle)
        return v;
    };
    /**
     * TODO:
     * LOOKUP:https://threejs.org/examples/webgl_points_sprites.html
     * https://github.com/mrdoob/three.js/blob/master/examples/webgl_points_sprites.html
     *
     */
    M._Line = function (vs, ve, col=0x110faa, lw=15, od=false) {
        let lmat = new THREE.LineBasicMaterial ({color:col, linewidth:lw});
        let lgeo = new THREE.BufferGeometry();
        let verts = [vs.x, vs.y, vs.z, ve.x, ve.y, ve.z];
        let parr = new Float32Array(verts);
        if (!od) {
            lgeo.addAttribute ('position', new THREE.BufferAttribute (parr, 3));
            let line = new THREE.Line(lgeo, lmat);
            line.castShadow = true;
            scene.add(line);
        }
        return parr;
    }; // M._Line(M._V([0, 0, 32]), M._V([33, 100, 66]));

    M._EllArc = function (vCenter, hAxs=[10, 10], aS=math.PI, aE=math.PI*2, col=0x00ffff, lw=15, od=false) {
        function ex (ang, a=hAxs[0]) {return a * math.cos(ang)}
        function ey (ang, b=hAxs[1]) {return b * math.sin(ang)}
        let verts = new Float32Array((M._Na+1) * 3);
        let way = aE - aS;
        let step = way / M._Na;
        for (let i=0;i<=M._Na;i++) {
            verts[i*3  ] = ex(i * step + aS)    + vCenter.x;
            verts[i*3+1] = 0                    + vCenter.y;
            verts[i*3+2] = ey(i * step + aS)    + vCenter.z;
        }
        let parr = new Float32Array(verts);
        if (!od) {        
            let lmat = new THREE.LineBasicMaterial ({color:col, linewidth:lw, transparent:true, opacity:1});
            let lgeo = new THREE.BufferGeometry();
            lgeo.addAttribute ('position', new THREE.BufferAttribute (parr, 3));
            let line = new THREE.Line(lgeo, lmat);
            line.castShadow = true;
            scene.add(line);
        }
        return parr;
    }; //M._EllArc(M._V([-50, 0, 0]), hAxs=[25, 150], aS=math.radians(0), aE=math.radians(360));

    M._DotsArc = function (d0, d1, focus, od=false) {
        let ar0 = M._IAngle(d0, focus), 
            ar1 = M._IAngle(d1, focus);
        return M._EllArc(
            focus, 
            hAxs=f(ar0.rad),
            aS=ar0.angle,
            aE=ar1.angle,
            od=od
        );
    }

    M._Name = function (arr, pref) {
        return pref + arr.join("_");
    };

    M._Dot = function (vDot, rad=.5, col=0xce21a5) { //accepts InSect of Vector3
        /**
         * SphereBufferGeometry(
         *  radius : Float,
         *  widthSegments : Integer,
         *  heightSegments : Integer,
         *  phiStart : Float,
         *  phiLength : Float,
         *  thetaStart : Float, thetaLength : Float
         */
        if (!vDot) return;
        // M._Points = M._Points || {};
        // let ar = vDot.toArray();
        // let dn = M._Name(ar);
        let sgeo = new THREE.SphereBufferGeometry (rad, 13, 17);
        let smat = new THREE.MeshPhongMaterial ({
            color:col,
            shininess:75,
            // flatShading:true,
            // transparent:true,
            // opacity:.75,
            depthTest:true,
            // side:THREE.FrontSide
        });
        let sph = new THREE.Mesh(sgeo, smat);
        sph.castShadow = true;
        sph.position.set(vDot.x, vDot.y, vDot.z)
        scene.add(sph);
    };// M._Dot(M._V([50, 50, 19]));

    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////

    M.Wave = {}; M.Wave.graph = function () {
        let W = M.Wave;
        W.wPERIOD =          3;//wave length coefficient
        W.wRANGE =           13;//quantity of loops
        W.wRRUN =            4;//within how many loops the radius changes from min to max or backwards
        W.wSHEER_FACTOR =    .5;
        W.wCIRCLE =          360;//number of degrees in a loop
        W.wRADIUS =          2;//just the radius of a wave
        W.wZSHIFT =          .005;
        /** sheer polarization is governed by the radius of ellipse at the given point
         * всё есть здесь: https://ru.wikipedia.org/wiki/Эллипс
         * r = (_BHA * _LHA) / sqrt(_LHA* *2 * cos(radians(BHA_Point_angle))** 2 + _BHA** 2 * sin(radians(BHA_Point_angle))**2)
         * or:  excentricity = sqrt(1 - _LHA* *2 / _BHA**2)
         * r = _LHA / sqrt(1 - excentricity* *2 * cos(BHA_Point_angle)**2)
         */
        W.wELLIPSE =            1;//0: ellipse, 1: ellipse + z-running r-shift, 2: z-running r-shift
        W.wBHA =                W.wRADIUS;
        W.wLHA =                W.wRADIUS / 2;
        W.wEANGLE =             W.wCIRCLE / 12;//angle of the _BHA inclination
        W.wROTEAN =             false;//rotate _EANGLE by the _CIRCLE/_RANGE part for each iteration. Experimental, has explicable rips
        let res =               [];
        let rfactor =           -1;
        let sfactor =           (r) => {return (r / W.wSHEER_FACTOR) / W.wCIRCLE};//sheer factor
        let r =                 W.wRADIUS;
        let bha =               W.wBHA;
        let lha =               W.wLHA;
        let rng =               math.round(W.wCIRCLE * W.wRANGE);
        let elrad =             (b, l, phi) => {return ((b * l) / math.sqrt(l**2 * math.cos(phi)**2 + b**2 * math.sin(phi)**2))};
        for (let angle=0;angle<rng;angle++) {
            let aa = W.wROTEAN % W.wCIRCLE;
            let BHA_Point_angle = aa - W.wEANGLE;
            if (W.wROTEAN) {
                if (aa == 0) {
                    W.wEANGLE = W.wEANGLE + (W.wCIRCLE / W.wRANGE);
                }
            }
            if (W.wELLIPSE == 0) {//try elliptical polarization
                r = elrad(W.wBHA, W.wLHA, BHA_Point_angle);
            } else if (W.wELLIPSE == 1) {//try'em both
                if (angle % (W.wCIRCLE * W.wRRUN) == 0) {
                    rfactor = -rfactor;
                }
                bha = bha + rfactor * sfactor(W.wBHA);
                lha = lha + rfactor * sfactor(W.wLHA);
                r = elrad(bha, lha, BHA_Point_angle);
            } else if (W.wELLIPSE == 2) {//try just changing radius for several cycles, TODO: may be joined to the elliptical polarization
                if (angle % (W.wCIRCLE * W.wRRUN) == 0) {
                    rfactor = -rfactor;
                }
                r = r + rfactor * sfactor (W.wRADIUS);
            } else {
                ;//static radius
            }
            let c0 = r * math.exp (math.complex(0, math.radians(aa)));
            let time = W.wPERIOD / W.wCIRCLE * angle;
            let p0 = [math.re(c0), math.im(c0), time];
            res.push(p0)
        }
        return res;
    }

    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////

    M.G = function () {}; M.G.PathConsts = {
        // 0 doesn't shine
        '4d__': "0- -0 0+ +0", //regular group - in both Is
        // e1 shines (connects to closests on bA), on I1 1e-dots are w/out grandchildren (He-sofits)
        'e1I1': "0- -+ +0", //first ellipse groups, going first towards T-focus (A -> T)
        // e1 out of I1 becomes BA, which can be traced geometrically, joining dots of 1eI1 and
        // continuing the lines bsmoothily to out-of-I1BA (or towards vA). Note that 1e, going BA, divides by direction
        'bAI2': "0- -0 ++", //"+0 0+ --", #no 1e on I2: BA from A out
        'bTI2': "-0 0- ++", //no 1e on I2: BA from T out
        //TODO: write functions for smoothing lines - between angles between dots of arcs
        '3uI1':"",'3uI2':"",'3dI1':"",'3dI2':"",'3rI1':"",'3rI2':"",'3lI1':"",'3lI2':""
    }

    M.G.pex1th = function (a, t, pathcode) {
        let pa = pathcode.split(" ");
        let path = [[a, t]];
        for (let i=0;i<pa.length;i++) {
            path.push(pa[i]);
            switch (pa[i]) {
                case "0-": path.push([a,   t-1]);break;
                case "0+": path.push([a,   t+1]);break;
                case "-0": path.push([a-1, t  ]);break;
                case "+0": path.push([a+1, t  ]);break;
                case "-+": path.push([a-1, t+1]);break;
                case "+-": path.push([a+1, t-1]);break;
                case "--": path.push([a-1, t-1]);break;
                case "++": path.push([a+1, t+1]);break;
            }
            a = path[path.length-1][0];
            t = path[path.length-1][1];
        }
        return path;
    };

    M.G.Yrkwampex1th = function (pex1th) {
        for (let i=0;i<pex1th.length;i+=2) { //we skip pathfrase item
            let a = pex1th[i][0], t = pex1th[i][1];
            if (!M._InSect(a, t))
                return false;
        }
        return true;
    };

    M.G.o1o = function (path, od=false) {
        if (!M.G.Yrkwampex1th(path)) return false;
        let wyan = [];
        for (let i=0;i<=path.length-1;i+=2) {
            if (i==path.length-1) {break}
            let a = path[i][0], 
                t = path[i][1];
            let d0 = M._InSect(a, t)
            let arr = [a, t];
            pfr = path[i+1].split("");
            for (let c=0;c<pfr.length;c++) {
                if (pfr[c] == '+')
                    arr[c] += 1;
                else if (pfr[c] == '-')
                    arr[c] -= 1;
            }
            let d1 = M._InSect(arr[0], arr[1]);
            let index = pfr.indexOf('0');
            let foci = [M._A, M._T];
            if (index > -1){
                wyan.push(M._DotsArc(d0, d1, foci[index], od=od));
            } else {
                wyan.push(M._Line(d0, d1, od=od));
            }
        }
        return wyan;
    };

    M.G.Y_Wyan = function (a, t, od=false) {
        let path="";
        if (a==0||t==0) {
            return false;
        } else {
            path = M.G.PathConsts['4d__'];
            if (a+t==M.Xer1-1) {
                return false;
            } else if (a+t==M.Xer1) {
                path = M.G.PathConsts['e1I1'];
            } else if (a>=M.Xer1||t>=M.Xer1) {
                let l = math.min([a, t]), h = math.max([a, t]);
                if (h-l<=M.Xer1-1){
                    if(h-1==M.Xer1-1) {
                        if (a>t) {path = M.G.PathConsts['bTI2']}
                        else {path = M.G.PathConsts['bAI2']}
                    } else {
                        path = M.G.PathConsts['4d__'];
                    }
                } else {
                    return false;
                }
            }
            let p = M.G.pex1th(a, t, path);
            // console.log(p);
            return M.G.o1o(p, od=od);
        }
    };

    M.G.Ftaex1Wyan = function (wyanDotsArray) {
        var f32wda = [];
        for (let i=0;i<wyanDotsArray.length;i++) {
            for (let j=0;j<wyanDotsArray[i].length;j++) {
                f32wda.push(wyanDotsArray[i][j]);}} 
        /** 
         * 1 2 3 4 5 6 7 8 9 a b c d e f g h i j k: 12k, kj2, 23j, ji3, 34i, ih4, 45h
         * https://en.wikipedia.org/wiki/Hyperbolic_space
         * https://ru.wikipedia.org/wiki/Конформно-евклидова_модель
         */
        var wgeo1 = new THREE.Geometry();
        (function makeVertsFaces (arr) {
            /** */
            for (let i=0;i<arr.length;i+=3) {
                wgeo1.vertices.push(new THREE.Vector3(arr[i], arr[i+1], arr[i+2]));
                // if (arr[i]=='undefined') console.log('shit at x:' + i);
                // if (arr[i+1]=='undefined') console.log('shit at y:' + (i+1));
                // if (arr[i+2]=='undefined') console.log('shit at z:' + (i+2));
            }
            let ps = wgeo1.vertices;
            for (let i=1;i<ps.length;i+=10) {
                for (let j=ps.length-1;j>1;j-=10){
                    wgeo1.faces.push(new THREE.Face3(i-1, i, j, M._Norm));
                    wgeo1.faces.push(new THREE.Face3(j, j-1, i, M._Norm));
                }
            }
        })(f32wda);
        wgeo1.computeVertexNormals();
        wgeo1.computeFaceNormals();
        wgeo1.normalize();
        // let wda = Float32Array.from(f32wda);
        // let ba = new THREE.BufferAttribute(wda, 3);
        // let wgeo = new THREE.BufferGeometry().fromGeometry(wgeo1)
        // wgeo.addAttribute('position', ba);
        let wmat = new THREE.MeshPhongMaterial ({
            color: math.round(
                //math.random() * 
                0x99ff99
                ),
            side: THREE.DoubleSide,
            // wireframe: true,
        });
        let wm = new THREE.Mesh(wgeo1, wmat);
        wm.position.z -= 10;
        scene.add ( wm );
        return wm;
    };

    M._DTest = function (){
        let cA0=8, cA1=9, cT0=16;
        M._EllArc(M._A,hAxs=f(M._Mok1*cA0));
        M._EllArc(M._A,hAxs=f(M._Mok1*cA1));
        M._EllArc(M._T,hAxs=f(M._Mok1*cT0));
        let d0=M._InSect(cA0,cT0),
            d1=M._InSect(cA1,cT0),
            cc=M._T;
        M._DotsArc(d0, d1, cc, od=false);
    }; //M._DTest();

    M.VM231_Dots = function () {
        for (let i=0;i<M._Xer1;i++) {
            // M._EllArc(M._A,hAxs=[M._Mok1 * i, M._Mok1 * i]);
            // M._EllArc(M._T,hAxs=[M._Mok1 * i, M._Mok1 * i]);
            for(let j=0;j<M._Xer1;j++) {
                let res = M._InSect(i, j);
                if (typeof(res) != 'undefined') {
                    M._Dot(res);
                }
            }
        }
    }; M.VM231_Dots ();

    M.G.Test = function(){
        // let cA0=15, cA1=9, cT0=16;
        // return M.G.Y_Wyan(cA1, cT0);
        for (let i=0;i<M._Xer1;i++) {
            for(let j=0;j<M._Xer1;j++) {
                let res = M._InSect(i, j);
                let w;
                if (typeof(res) != 'undefined') {
                    
                    // if (i == 13 & j == 13) {
                        w = M.G.Y_Wyan(i, j);
                        let o = M.G.Ftaex1Wyan(w);
                        // console.log(o == o);
                    // }
                }

            }
        }
    }; M.G.Test();

    (()=>{

        M._Dot(M._A, rad=2, col='black');
        M._Dot(M._T, rad=2, col='white');

    })();
})();

(function fnTestObjects(){
    (function oSphere(){
        // Sphere parameters: radius, segments along width, segments along height
        var sphereGeometry = new THREE.SphereGeometry( 10, 17, 17 );
        // use a "lambert" material rather than "basic" for realistic lighting.
        //   (don't forget to add (at least one) light!)
        var sphereMaterial = new THREE.MeshLambertMaterial( {color: 0x8888ff} );
        sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
        sphere.position.set(10, -1, +5);
        sphere.castShadow = true;
        sphere.receiveShadow = true;
        sphere._lType = "sph";
        scene.add(sphere);
        //#####################################################################################
        //#####################################################################################
    });//();
    (function oCube(){
        // Create an array of materials to be used in a cube, one for each side
        var cubeMaterialArray = [];
        // order to add materials: x+,x-,y+,y-,z+,z-
        cubeMaterialArray.push( new THREE.MeshBasicMaterial( { color: 0xff3333, wireframe:true} ) );
        cubeMaterialArray.push( new THREE.MeshBasicMaterial( { color: 0xff8800 } ) );
        cubeMaterialArray.push( new THREE.MeshBasicMaterial( { color: 0xffff33, wireframe:true } ) );
        cubeMaterialArray.push( new THREE.MeshBasicMaterial( { color: 0x33ff33 } ) );
        cubeMaterialArray.push( new THREE.MeshBasicMaterial( { color: 0x3333ff, wireframe:true } ) );
        cubeMaterialArray.push( new THREE.MeshBasicMaterial( { color: 0x8833ff } ) );
        // Cube parameters: width (x), height (y), depth (z),
        //        (optional) segments along x, segments along y, segments along z
        var cubeGeometry = new THREE.CubeGeometry( 10, 10, 10, 13, 11, 17 );
        // using THREE.MeshFaceMaterial() in the constructor below
        //   causes the mesh to use the materials stored in the geometry
        cube = new THREE.Mesh( cubeGeometry, cubeMaterialArray );
        cube.position.set(-6, 5, -5);
        cube.castShadow = true;
        cube.receiveShadow = true;
        scene.add( cube );

        //#####################################################################################
        //#####################################################################################
    });//();
    (function oSph1(){
        //SPHERE WITH OUTLINE
        var sph1Geometry = new THREE.SphereGeometry( 7, 17, 17 );
        // use a "lambert" material rather than "basic" for realistic lighting.
        //   (don't forget to add (at least one) light!)
        var sph1Material = new THREE.MeshLambertMaterial( {color: 0x8888ff} );
        sph1 = new THREE.Mesh(sph1Geometry, sph1Material);
        sph1.position.set(50, -4, +5);
        sph1.castShadow = true;
        sph1.receiveShadow = true;
        sph1._lType = "sph";
        scene.add(sph1);
        //////////////////////////////////////
        var outlineMaterial1 = new THREE.MeshBasicMaterial( { color: 0xff0000, side: THREE.BackSide } );
        var outlineMesh1 = new THREE.Mesh( sph1Geometry, outlineMaterial1 );
        posSetEqual(outlineMesh1, sph1)
        outlineMesh1.scale.multiplyScalar(1.05);
        scene.add( outlineMesh1 );
        //#####################################################################################
        //#####################################################################################
    });//();
    (function oSph2(){
        var sph2Geometry = new THREE.SphereGeometry( 7, 17, 17 );
        // use a "lambert" material rather than "basic" for realistic lighting.
        //   (don't forget to add (at least one) light!)
        var sph2Material = new THREE.MeshLambertMaterial( {color: 0x8888ff} );
        sph2 = new THREE.Mesh(sph2Geometry, sph2Material);
        sph2.position.set(30, -4, +25);
        sph2.castShadow = true;
        sph2.receiveShadow = true;
        sph2._lType = "sph";
        scene.add(sph2);
        //#####################################################################################
        //#####################################################################################
    });//();
    (function fnDragger(){
        dragObjs.push(/*cube, */sph2);
        /*
        TODO: https://threejs.org/examples/#misc_controls_transform
        Good  example
        https://github.com/mrdoob/three.js/blob/master/examples/misc_controls_transform.html
        usage - lines near 90
        */
        mouseDragger = new ThreeDragger([], camera, renderer.domElement);
        mouseDragger.on('dragstart', function (data) {
          OrbitControls.enabled = false;
        });
        mouseDragger.on('drag', function (data) {
          const {
            target,
            position
          } = data;
          target.position.set(position.x, position.y, position.z);
        });
        mouseDragger.on('dragend', function (data) {
            OrbitControls.enabled = true;
        });
        mouseDragger.update(dragObjs);

    });//();
    (function guiSetup() {
        //GUI SETUP
        gui = new dat.GUI();
        parameters =
        {
            x: 17, y: 9, z: 17,
            color:  "#ff0000", // color (change "#" to "0x")
            colorA: "#000000", // color (change "#" to "0x")
            colorE: "#000033", // color (change "#" to "0x")
            colorS: "#ffff00", // color (change "#" to "0x")
            shininess: 30,
            opacity: .65,
            visible: true,
            material: "Phong",
            reset: function() { resetSphere() }
        };

        var folder1 = gui.addFolder('Position');
        var sphereX = folder1.add( parameters, 'x' ).min(-200).max(200).step(1).listen();
        var sphereY = folder1.add( parameters, 'y' ).min(0).max(100).step(1).listen();
        var sphereZ = folder1.add( parameters, 'z' ).min(-200).max(200).step(1).listen();
        folder1.open();

        sphereX.onChange(function(value)
        {   sphere.position.x = value;   });
        sphereY.onChange(function(value)
        {   sphere.position.y = value;   });
        sphereZ.onChange(function(value)
        {   sphere.position.z = value;   });

        var sphereColor = gui.addColor( parameters, 'color' ).name('Color (Diffuse)').listen();
        sphereColor.onChange(function(value) // onFinishChange
        {   sphere.material.color.setHex( value.replace("#", "0x") );   });
        var sphereColorA = gui.addColor( parameters, 'colorA' ).name('Color (Ambient)').listen();
        sphereColorA.onChange(function(value) // onFinishChange
        {   sphere.material.ambient.setHex( value.replace("#", "0x") );   });
        var sphereColorE = gui.addColor( parameters, 'colorE' ).name('Color (Emissive)').listen();
        sphereColorE.onChange(function(value) // onFinishChange
        {   sphere.material.emissive.setHex( value.replace("#", "0x") );   });
        var sphereColorS = gui.addColor( parameters, 'colorS' ).name('Color (Specular)').listen();
        sphereColorS.onChange(function(value) // onFinishChange
        {   sphere.material.specular.setHex( value.replace("#", "0x") );   });
        var sphereShininess = gui.add( parameters, 'shininess' ).min(0).max(60).step(1).name('Shininess').listen();
        sphereShininess.onChange(function(value)
        {   sphere.material.shininess = value;   });
        var sphereOpacity = gui.add( parameters, 'opacity' ).min(0).max(1).step(0.01).name('Opacity').listen();
        sphereOpacity.onChange(function(value)
        {   sphere.material.opacity = value;   });

        var sphereMaterial = gui.add( parameters, 'material', [ "Basic", "Lambert", "Phong", "Wireframe" ] ).name('Material Type').listen();
        sphereMaterial.onChange(function(value)
        {   updateSphere();   });

        gui.add( parameters, 'reset' ).name("Reset Sphere Parameters");

        gui.open();
        updateSphere()

        function updateSphere() {
            var value = parameters.material;
            var newMaterial;
            if (value == "Basic")
                newMaterial = new THREE.MeshBasicMaterial( { color: 0x000000 } );
            else if (value == "Lambert")
                newMaterial = new THREE.MeshLambertMaterial( { color: 0x000000 } );
            else if (value == "Phong")
                newMaterial = new THREE.MeshPhongMaterial( { color: 0x000000 } );
            else // (value == "Wireframe")
                newMaterial = new THREE.MeshBasicMaterial( { wireframe: true } );
            sphere.material = newMaterial;

            sphere.position.x = parameters.x;
            sphere.position.y = parameters.y;
            sphere.position.z = parameters.z;
            sphere.material.color.setHex( parameters.color.replace("#", "0x") );
            if (sphere.material.ambient)
                sphere.material.ambient.setHex( parameters.colorA.replace("#", "0x") );
            if (sphere.material.emissive)
                sphere.material.emissive.setHex( parameters.colorE.replace("#", "0x") );
            if (sphere.material.specular)
                sphere.material.specular.setHex( parameters.colorS.replace("#", "0x") );
            if (sphere.material.shininess)
                sphere.material.shininess = parameters.shininess;
            sphere.material.opacity = parameters.opacity;
            sphere.material.transparent = true;
        }
        function resetSphere() {
            parameters.x = 0;
            parameters.y = 30;
            parameters.z = 0;
            parameters.color = "#ff0000";
            parameters.colorA = "#000000";
            parameters.colorE = "#000033";
            parameters.colorS = "#ffff00";
            parameters.shininess = 30;
            parameters.opacity = 1;
            parameters.visible = true;
            parameters.material = "Phong";
            updateSphere();
        }
    });//();
    (function css3d(){
        /**
         * https://forge.autodesk.com/cloud_and_mobile/2015/07/embedding-webpages-in-a-3d-threejs-scene.html
         *
         * https://github.com/jeromeetienne/threex.htmlmixer
         */
        mixerContext= new THREEx.HtmlMixer.Context(renderer, scene, camera)
        mixerContext.rendererCss.setSize( window.innerWidth, window.innerHeight )
        rendererCSS		= mixerContext.rendererCss;
        resizerCSS = new THREEx.WindowResize( rendererCSS, camera );

        // set up rendererWebgl
        var rendererWebgl	= mixerContext.rendererWebgl
        var css3dElement		= rendererCSS.domElement
        css3dElement.style.position	= 'absolute'
        css3dElement.style.top		= '0px'
        css3dElement.style.width	= '100%'
        css3dElement.style.height	= '100%'
        document.body.appendChild( css3dElement )
        var webglCanvas			= rendererWebgl.domElement
        webglCanvas.style.position	= 'absolute'
        webglCanvas.style.top		= '0px'
        webglCanvas.style.width		= '100%'
        webglCanvas.style.height	= '100%'
        webglCanvas.style.pointerEvents	= 'none'
        css3dElement.appendChild( webglCanvas )

        var url		= '../chs/chs0/css/img/Zero.png';
        // var url = 'http://localhost:8001/waap';
        var domElement	= THREEx.HtmlMixerHelpers.createImageDomElement(url)

        console.log('domElement', domElement)

        var mixerPlane	= new THREEx.HtmlMixer.Plane(mixerContext, domElement, {
            elementW:200,
            planeW: 1,
            planeH: height
        })
        scene.add( mixerPlane.object3d )


    });//();
});//();


