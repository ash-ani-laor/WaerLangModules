/*
    //Интересно: https://ru.wikipedia.org/wiki/Матрица_поворота
    //https://ru.wikipedia.org/wiki/Пространственно-временная_диаграмма
    //https://github.com/stemkoski/stemkoski.github.com/tree/master/Three.js
    //https://github.com/stemkoski/stemkoski.github.com/tree/master/Three.js/images
    //https://stemkoski.github.io/Three.js/
    //https://github.com/mrdoob/three.js/

    http://www.threejsgames.com/extensions/

    http://svgdiscovery.com/THREEjs/CSS3D/examples-CSS3D-SVG.htm (SEEN.JS)

    //https://free3d.com/

    //https://jtiscione.github.io/chessboard3js/docs.html
    //https://github.com/SuperiorJT/Threejs-Chess

    //https://habr.com/ru/post/436482/ - шейдерные материалы и постобработка
*/
var M, G, scene, camera, renderer, labelRenderer, axesHelper, OrbitControls, resizer, light, lightbulb, skyBox, INTERSECTED, raycaster /* look on raycasting here https://threejs.org/examples/#webgl_raycast_texture */,mouse, parameters, sphere, cube, sph1, sph2, slight, slightHelper, dragObjs=[] /* https://keqingrong.github.io/three-dragger/example/ */,cssScene, rendererCSS, resizerCss, mixerContext; // let GLOBALBIT = false;
function f(a) {return[a,a]};

function MAIN (){
    function posSetEqual(obj1, obj2) {
        obj1.position.set(obj2.position.x, obj2.position.y, obj2.position.z);
    };

    MAIN.posSetEqual = posSetEqual;
    // Converts from degrees to radians.
    math.radians = function(degrees) {
        return degrees * math.PI / 180;
    };
    // Converts from radians to degrees.
    math.degrees = function(radians) {
        return radians * 180 / math.PI;
    };
    function basicSetup() {
        scene = new THREE.Scene();

        //on group camera rotation - https://stackoverflow.com/questions/50060423/three-js-rotate-camera-separately-from-its-parent?rq=1
        camera = new THREE.PerspectiveCamera( 45, window.innerWidth/window.innerHeight, 0.1, 1000000 );

        renderer = new THREE.WebGLRenderer({alpha:true});
        renderer.setSize( window.innerWidth, window.innerHeight );
        renderer.setPixelRatio( window.devicePixelRatio );
        renderer.setClearColor(new THREE.Color('black'), 0)
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFShadowMap;

        labelRenderer = new THREE.CSS2DRenderer();
        labelRenderer.setSize( window.innerWidth, window.innerHeight );
        // labelRenderer.setPixelRatio( window.devicePixelRatio );
        // labelRenderer.setClearColor(new THREE.Color('black'), 0)
        // labelRenderer.shadowMap.enabled = true;
        // labelRenderer.shadowMap.type = THREE.PCFShadowMap;
        labelRenderer.domElement.style.position = 'absolute';
        labelRenderer.domElement.style.top = '0';
        labelRenderer.domElement.style.pointerEvents = 'none';

        // document.getElementById( 'container' ).appendChild( renderer.domElement );
        // document.getElementById( 'container' ).appendChild( labelRenderer.domElement );
        document.body.appendChild( renderer.domElement );
        document.body.appendChild( labelRenderer.domElement );

        camera.position.set(0, 5100, -10); //125000
        // camera.rotation.y = math.PI;
        // camera.matrix.fromArray(JSON.parse(
            // from JSON.stringify(camera.matrix.toArray())
            //and still doesn't work (((
                // "[0.9990026142855373,3.469446951953614e-18,0.04465172617785408,0,0.044651726177831745,0.0000010001554604510685,-0.9990026142850376,0,-4.465866775688054e-8,0.9999999999994998,9.991579197343723e-7,0,0.41827075941864145,100.90216614733063,0.5191194457329098,1]"
        // ));
        // camera.matrix.decompose(camera.position, camera.quaternion, camera.scale);

        axesHelper = new THREE.AxesHelper(10);
        scene.add( axesHelper );

        resizer = new THREEx.WindowResize( renderer, camera );

        OrbitControls = new THREE.OrbitControls(camera);

        raycaster = new THREE.Raycaster();
        mouse = new THREE.Vector2();
        function onMouseMove( event ) {
            // calculate mouse position in normalized device coordinates
            // (-1 to +1) for both components
            mouse.x = ( event.clientX / window.innerWidth ) * 2 - 1;
            mouse.y = - ( event.clientY / window.innerHeight ) * 2 + 1;
        }
        window.addEventListener( 'mousemove', onMouseMove, false );

        function animate () {
            requestAnimationFrame( animate );

            /** TODO: RAYCASTER DOESN'T WORK! //update the picking ray with the camera and mouse position
            raycaster.setFromCamera( mouse, camera ); (function fnIntersect() {
            // https://github.com/mrdoob/three.js/issues/1934 *
            const insterss = raycaster.intersectObjects( scene.children );
            for (var i=0;i<insterss.length; i++) {}})();*/

            OrbitControls.update();

            // mixerContext.update(); // - TODO:uncomment this, if need a css-renderer
            labelRenderer.render( scene, camera );
            renderer.render( scene, camera );
        };
        animate();
    }; basicSetup();
    function grids(size=50, step=10){
        //GRID
        var gridXZ = new THREE.GridHelper(size, step, colorCenterLine=new THREE.Color(0x006600), colorGrid=new THREE.Color(0x006600));
        gridXZ.position.set( 25,-15,25 );
        scene.add(gridXZ);
        var gridXY = new THREE.GridHelper(size, step, colorCenterLine=new THREE.Color(0x000066), colorGrid=new THREE.Color(0x000066));
        gridXY.position.set( 25,25,-15 );
        gridXY.rotation.x = math.PI/2;
        scene.add(gridXY);
        var gridYZ = new THREE.GridHelper(size, step, colorCenterLine=new THREE.Color(0x660000), colorGrid=new THREE.Color(0x660000));
        gridYZ.position.set( -15,25,25 );
        gridYZ.rotation.z = math.PI/2;
        scene.add(gridYZ);
    };//();
    function skybox(){
        // SKYBOX
        var skyBoxGeometry = new THREE.BoxGeometry( 1000000, 1000000, 1000000 );
        var skyBoxMaterial = new THREE.MeshBasicMaterial( { color: 0xeebbee, side: THREE.BackSide } );
        skyBox = new THREE.Mesh( skyBoxGeometry, skyBoxMaterial );
        scene.add(skyBox);
        ////////EITHER SKYBOX OR FOG
        //FOG
        // scene.fog = new THREE.FogExp2( 0x335566, 0.01);//0.00025 );
    };skybox();
    function lightSetup(){
        // general light
        var ambientLight = new THREE.AmbientLight(0xffffff, 1);
        scene.add(ambientLight);
        // light to see some volume
        light = new THREE.PointLight(0xffffff,2);
        light.position.set(300, 1000, -500);
        scene.add(light);
        //#####################################################################################
        /*  //lightbulb
            var lightbulbGeometry = new THREE.SphereGeometry( 3, 8, 8 );
            var lightbulbMaterial = new THREE.MeshBasicMaterial( { color: 0xffffff, transparent: true,  opacity: 0.9, blending: THREE.AdditiveBlending } );
            var wireMaterial = new THREE.MeshBasicMaterial( { color: 0x000000, wireframe: true } );
            var materialArray = [lightbulbMaterial, wireMaterial];
            lightbulb = THREE.SceneUtils.createMultiMaterialObject( lightbulbGeometry, materialArray );
            MAIN.posSetEqual(lightbulb, light);
            scene.add(lightbulb);
            //#####################################################################################
            var slight = new THREE.SpotLight( 0x441188, .9 );
            slight.position.set( 65, 90, 10 );
            slight.angle = math.PI / 9;
            slight.castShadow = true;
            slight.shadow.camera.near = 1000;
            slight.shadow.camera.far = 4000;
            slight.shadow.mapSize.width = 1024;
            slight.shadow.mapSize.height = 1024;
            scene.add( slight );
        */
        //#####################################################################################
        // var slightHelper = new THREE.SpotLightHelper( slight );
        // scene.add(slightHelper);
        //LET THERE BE LIGHT. Some more light.
        const pointLight = new THREE.PointLight(0xffffff, 1);
        pointLight.position.set(0, 1000, 400);
        scene.add(pointLight);
        pointLight.color.setHSL(Math.random(), 1, 0.5);
    };lightSetup();
    function baseSetup(){
        //BASE
        if (false) {
            planeGeo = new THREE.PlaneGeometry(32,32);
            planeMat = new THREE.MeshBasicMaterial({color:0xbbbbbb, opacity:.8, transparent: true});
            basePlane = new THREE.Mesh(planeGeo, planeMat);
            basePlane.rotation.x = -math.PI / 2;
            basePlane.position.set(9,-5,9);
            basePlane.base = true;
            scene.add(basePlane);
            //} else {
            function mipmap( size, color ) {

                var imageCanvas = document.createElement( "canvas" ),
                    context = imageCanvas.getContext( "2d" );

                imageCanvas.width = imageCanvas.height = size;

                context.fillStyle = "#444";
                context.fillRect( 0, 0, size, size );

                context.fillStyle = color;
                context.fillRect( 0, 0, size / 2, size / 2 );
                context.fillRect( size / 2, size / 2, size / 2, size / 2 );
                return imageCanvas;

            }

            var canvas = mipmap( 128, '#f00' );
            var textureCanvas1 = new THREE.CanvasTexture( canvas );
            textureCanvas1.mipmaps[ 0 ] = canvas;
            textureCanvas1.mipmaps[ 1 ] = mipmap( 64, '#0f0' );
            textureCanvas1.mipmaps[ 2 ] = mipmap( 32, '#00f' );
            textureCanvas1.mipmaps[ 3 ] = mipmap( 16, '#400' );
            textureCanvas1.mipmaps[ 4 ] = mipmap( 8, '#040' );
            textureCanvas1.mipmaps[ 5 ] = mipmap( 4, '#004' );
            textureCanvas1.mipmaps[ 6 ] = mipmap( 2, '#044' );
            textureCanvas1.mipmaps[ 7 ] = mipmap( 1, '#404' );
            textureCanvas1.repeat.set( 1000, 1000);
            textureCanvas1.wrapS = THREE.RepeatWrapping;
            textureCanvas1.wrapT = THREE.RepeatWrapping;

            var materialCanvas1 = new THREE.MeshBasicMaterial( { map: textureCanvas1 } );

            var geometry = new THREE.PlaneBufferGeometry( 100, 100 );

            var meshCanvas1 = new THREE.Mesh( geometry, materialCanvas1 );
            meshCanvas1.rotation.x = - math.PI / 2;
            meshCanvas1.position.y -= 56
            meshCanvas1.scale.set( 100, 100, 100 );

            scene.add( meshCanvas1 );
        } else {
            ;
        }
    };//();
};

dbmInit = function (I, X1, add) {
    if (true) {
        M = MAIN; M.Obj = {}; M.G = () => {}; G = M.G;
        I = I || 1000;
        X1 = X1 || 2;
        add = add || 0;
        M.DotSize=15.6
        M.I = I;
        M.X1 = X1;
        M.X2 = X1 + add;
        M.Mok1 = I / (X1 - 1);
        M.Na = 10;
        M.YS = 0;//3000;
        M.CaMo = 2 * math.PI / M.Na; //part of angle for one step
        //https://threejs.org/docs/index.html#api/en/math/Vector3
        // TODO: and, BTW, https://threejs.org/docs/index.html#api/en/math/Spherical
        M.A =      new THREE.Vector3(-I/2, M.YS, 0);
        M.T =      new THREE.Vector3( I/2, M.YS, 0);
        M.Norm =   new THREE.Vector3(0,    1, 0);
        M.O =      new THREE.Vector3(0,    M.YS, 0);
        M.V = function (arr) {
            var r = new THREE.Vector3();
            r.fromArray(arr);
            return r;
        }
        M.InvFocus = M.V([M.O.x,M.O.y,M.O.z]);
        M.InvRadius = M.I;
    }
};

fnGeom = function(){

    M.Name = function (obj) {
        return md5(JSON.stringify(obj));
    };

    M.InSect = function (a, t, neg) {
        if(typeof(neg) == "undefined") neg = false;
        var ret = false;
        if (typeof(M.I) == 'undefined')
            M.dbmInit();
        let ar = M.Mok1 * a,
            tr = M.Mok1 * t,
            hp = (M.I + ar + tr) / 2;
        if(
            a + t >= M.X1-1 && //in I1
            math.abs(a - t) < M.X1 //not out of I2
        ) {

            let hI = 0, x = 0, coef = 1;
            try {hI = (2 * math.sqrt(hp * (hp - M.I) * (hp - ar) * (hp - tr) ) ) / M.I}
            catch(e) {hI = 0}

            if(isNaN(hI)) hI = 0;

            if (tr >= ar) {
                tr = [ar, ar = tr][0];
                coef = -1;
            }
            let sina = 0;
            if (ar != 0)
                sina = hI / ar;
            an = math.asin(sina);
            let sx = ar * math.cos(an);
            x = coef * (-M.I) / 2 + coef * sx; //correction of the position of adjacent katet
            ret = M.V([x, M.YS, neg?-hI:hI]);
        }
        return ret;
    };

    M.IAngle = function (not_inv_coord, focus) {
        let crd = new THREE.Vector3(); crd.subVectors(not_inv_coord, focus);
        return {rad: crd.distanceTo(M.O), angle: -crd.angleTo(M.T)};
    };

    M.Inverse = function (coords, focus, radius) {
        focus = focus || M.InvFocus;
        radius = radius || M.InvRadius;
        let dx = coords.x, dz = coords.z, fx = focus.x, fz = focus.z
        let x = dx + (math.pow(radius, 2) * (dx - fx)) / (math.pow(dx - fx, 2) + math.pow(dy - fy, 2));
        let z = dz + (math.pow(radius, 2) * (dz - fz)) / (math.pow(dx - fx, 2) + math.pow(dz - fz, 2));
        return M.V([x, M.YS, z]);
    };

    M.Line = function (vs, ve, onlyDots, col, lw, inv) {
        if (typeof(onlyDots=='undefined')) onlyDots = false;
        col = col || 0x00ffff;
        lw = lw || 15;
        if (typeof(inv =='undefined')) inv = false;

        let name = "";

        let vs0 = M.V([vs.x, vs.y, vs.z]);
        let ve0 = M.V([ve.x, ve.y, ve.z]);
        if (inv) {
            vs0 = M.Inverse(vs);
            ve0 = M.Inverse(ve);
        } else
            name = M.Name([vs0, ve0]);

        name = M.Name([vs0, ve0]);
        M.Obj[name] = {object:null, vertices:null};

        let lmat = new THREE.LineBasicMaterial ({color:col, linewidth:lw});
        let lgeo = new THREE.BufferGeometry();
        let verts = [vs0.x, vs0.y, vs0.z, ve0.x, ve0.y, ve0.z];
        let parr = new Float32Array(verts);
        if (!onlyDots) {
            lgeo.addAttribute ('position', new THREE.BufferAttribute (parr, 3));
            let line = new THREE.Line(lgeo, lmat);
            line.castShadow = true;
            M.Obj[name].object = line;
            scene.add(line);
        }
        M.Obj[name].vertices = verts;
        return verts;
    };

    // let N = 10, ctr = 0;
    M.EllArc = function (vCenter, hAxs, aS, aE, onlyDots, col, lw, inv, cw, shift) {
        if (true) {
            shift = shift || 0;
            hAxs = hAxs || [10, 10];
            aS = aS || 0;
            aE = aE || math.PI*2;
            if (typeof(onlyDots) == 'undefined') onlyDots = false;
            col = col || 0x00ffff;
            lw = lw || 15;
            if (typeof(inv) == 'undefined') inv = false;
            if (typeof(cw) == 'undefined') cw = false;
        }
        let name = M.Name([vCenter, hAxs, aS, aE, inv]);
        let curve = new THREE.EllipseCurve(vCenter.x, vCenter.z, hAxs[0], hAxs[1], aS, aE, cw, 0);
        let parr = curve.getPoints(M.Na);
        let parr0 = [], verts = [];

        M.Obj[name] = {object:null, vertices:null};

        for(let i=0;i<parr.length;i++) {
            // parr[i].y += shift;
            parr0[i] = M.V([parr[i].x, M.YS, parr[i].y]);
            if(inv) {
                parr0[i] = M.Inverse(parr0[i]);
                parr[i].x = parr0[i].x;
                parr[i].y = parr0[i].z;
            }

            // var col = undefined;
            // if (i == 0) col = 'red';

            verts[i*3+0] = parr0[i].x;
            verts[i*3+1] = parr0[i].y;
            verts[i*3+2] = parr0[i].z;
        }
        if (onlyDots == false) {
            let lmat = new THREE.LineBasicMaterial ({color:col, linewidth:lw, transparent:true, opacity:1});
            let lgeo = new THREE.BufferGeometry().setFromPoints(parr);
            // lgeo.addAttribute ('position', new THREE.BufferAttribute (parr, 3));
            let line = new THREE.Line(lgeo, lmat);
            line.castShadow = true;

            line.rotation.x = -math.PI/2;
            line.position.z += vCenter.z*2;

            scene.add(line);
            M.Obj[name].object = line;
        }

        M.Obj[name].vectors = parr0;
        M.Obj[name].vertices = verts;
        return verts;
    };

    M.Circle = function (focus, radius, inv, cl) {
        if (typeof(inv) == 'undefined') inv = false;
        if (typeof(col) == 'undefined') cl = M.getRandomColor();
        let old_na = M.Na;
        M.Na = 2460;
        let c = M.EllArc(
            focus,
            f(radius),
            undefined, undefined, undefined, col=cl, undefined,
            inv, undefined, undefined);
        M.Na = old_na;
        return c;
    }

    M.Dot = function (vDot, rad, col, visible) { //accepts InSect of Vector3
        rad = rad || .5;
        col = col || 0xce21a5;
        if(typeof(visible) == 'undefined')
            visible = true;
        let name = M.Name([vDot]);
        M.Obj[name] = {object:null, vertices:null};
        if (!vDot) return;
        let sgeo = new THREE.SphereBufferGeometry (rad, 13, 17);
        let smat = new THREE.MeshPhongMaterial ({
            color:col,
            shininess:75,
            // flatShading:true,
            // transparent:true,
            // opacity:.75,
            depthTest:true,
            // side:THREE.FrontSide
        });
        let sph = new THREE.Mesh(sgeo, smat);
        sph.castShadow = true;
        sph.position.set(vDot.x, vDot.y, vDot.z)
        M.Obj[name].object = sph;
        M.Obj[name].vertices = vDot;
        if (visible)
            scene.add(sph);
        return name;
    };

    M.Group = function(name, objects) {

        //LOOK: SECOND PARAMETER AS AN ARRAY!

        let grp = new THREE.Group();
        for (let i=0;i<objects.length;i++)
        grp.add( objects[i] );
        M.Obj[name] = {object: grp};
        return grp;
    };

};

fnGroup = function () {

    M.path_extant_P = function (pex1th) {
        if (!pex1th) return false;
        for (let i=0;i<pex1th.length;i+=2) { //we skip pathfrase item
            let a = pex1th[i][0], t = pex1th[i][1];
            if (!M.InSect(a, t))
                return false;
        }
        return true;
    };

    M.path = function (a, t) { //the form [[a, t], '+0', [a+1, t], ...]
        M.PathConsts = {
            // 0 doesn't shine
            '4d__': "0- -0 0+ +0", //regular group - in both Is
            // e1 shines (connects to closests on bA), on I1 1e-dots are w/out grandchildren (He-sofits)
            'e1I1': "0- -+ +0", //first ellipse groups, going first towards T-focus (A -> T)
            // e1 out of I1 becomes BA, which can be traced geometrically, joining dots of 1eI1 and
            // continuing the lines bsmoothily to out-of-I1BA (or towards vA). Note that 1e, going BA, divides by direction
            'bAI2': "0- -0 ++", //"+0 0+ --", #no 1e on I2: BA from A out
            'bTI2': "-0 0- ++", //no 1e on I2: BA from T out
            //TODO: write functions for smoothing lines - between angles between dots of arcs
            /**
             * в вянах от равноудалённых фокусов надо взять середину линии (А|Т-(A-1|T-1))/2
             * для кривых фигур вроде 2 эллипса И2 надо искать средневзвешенное положение
             * для точек, предполагая, что чем ближе к БО на втором эллипсе, тем легче точки;
             *
             * https://habr.com/ru/post/101338/ - обзор алгоритмов кластеризации
             * https://ru.stackoverflow.com/questions/480368/%D0%9F%D0%BE%D0%B8%D1%81%D0%BA-%D0%B3%D0%B5%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%BE%D0%B3%D0%BE-%D1%86%D0%B5%D0%BD%D1%82%D1%80%D0%B0-%D0%B3%D1%80%D1%83%D0%BF%D0%BF%D1%8B-%D0%BE%D0%B1%D1%8A%D0%B5%D0%BA%D1%82%D0%BE%D0%B2-%D0%B2-3d-%D0%BF%D1%80%D0%BE%D1%81%D1%82%D1%80%D0%B0%D0%BD%D1%81%D1%82%D0%B2%D0%B5-%D1%81-%D0%BF%D1%80%D0%B5%D0%B4%D0%B2%D0%B0%D1%80%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9
             */
            '3uI1':"",'3uI2':"",'3dI1':"",'3dI2':"",'3rI1':"",'3rI2':"",'3lI1':"",'3lI2':""
        };

        M.pex1th = function (a, t, pathcode) {
            let pa = pathcode.split(" ");
            let path = [[a, t]];
            for (let i=0;i<pa.length;i++) {
                path.push(pa[i]);
                switch (pa[i]) {
                    case "0-": path.push([a,   t-1]);break;
                    case "0+": path.push([a,   t+1]);break;
                    case "-0": path.push([a-1, t  ]);break;
                    case "+0": path.push([a+1, t  ]);break;
                    case "-+": path.push([a-1, t+1]);break;
                    case "+-": path.push([a+1, t-1]);break;
                    case "--": path.push([a-1, t-1]);break;
                    case "++": path.push([a+1, t+1]);break;
                }
                a = path[path.length-1][0];
                t = path[path.length-1][1];
            }
            return path;
        };

        let path="";
        if (a==0||t==0) { //zeros don't shine
            return false;
        } else { //non-zero dot
            path = M.PathConsts['4d__'];
            if (a+t==M.X1-1) { //BA doesn't shine
                return false;
            } else if (a+t==M.X1) { //first ellipsoid
                path = M.PathConsts['e1I1'];
            } else if (a>=M.X1||t>=M.X1) { //other dots
                let l = math.min([a, t]), h = math.max([a, t]);
                if (h-l<=M.X2-1){ //
                    if(h-l==M.X1-1) {
                        if (a>t) {path = M.PathConsts['bTI2']}
                        else {path = M.PathConsts['bAI2']}
                    } else {
                        path = M.PathConsts['4d__'];
                    }
                } else {
                    return false;
                }
            }
            let p = M.pex1th(a, t, path);
            return p; //in the form [[a, t], '+0', [a+1, t], ...]
        }
    };

    M.mark_wyan_dots = function (a, t) {
        //returns array of dot meshes
        let path = M.path(a, t), arr = [];
        if(M.path_extant_P(path)) {
            for (let i=0;i<path.length;i+=2) { //we skip pathfrase item
                let a = path[i][0], t = path[i][1], dot = M.InSect(a, t);
                let name = M.Name([dot])
                if (! (name in M.Obj)){
                    let dt0 = M.Dot(dot, rad=M.DotSize*2, col=abgd.getWordColor(abgd.pair_lat(a, t)), visible=true);
                    M.Obj[name] = {vertices:dot, object:dt0}
                    arr.push(M.Obj[name]);
                }
            }
        } else return false;
        return arr;
    };

    M.getRandomColor = function () {
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
          color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    };

    M.AddHebLang = function(start, base_length){ //must be run to start making wyans with adequate color
        abgd.start = start || 0;
        abgd.base_length = base_length || M.X1;
        if (abgd.start + abgd.base_length > M.X1)
          throw "Want too much of hebrew: " + start + abgd.base_length + " letters!";

        abgd.maxGem = 0;
        // https://uigradients.com/
        abgd.gradient = ['#000000', '#c50106', '#f5f100', '#ffffff'];//['#544a7d', '#ffd452'];//['#1e9600', '#fff200', '#ff0000'];

        (setLetters = function (){
          abgd.__rs = "abgdhvzxtiklmnsopcqrSTKMNPC".split("");
          abgd.rs = abgd.__rs.slice(start, abgd.base_length);
          /////////////////////////////////////////////////////////////////
          abgd.__rl = ["א", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט", "י", "כ", "ל", "מ",
                       "נ", "ס", "ע", "פ", "צ", "ק", "ר", "ש",
                       "ת", "ך", "ם", "ן", "ף", "ץ"];
          abgd.rl = abgd.__rl;
          /////////////////////////////////////////////////////////////////
          abgd.__es = ["lP", "iT", "ml", "lT", "i", "v", "in", "iT", "iT", "vd", "P", "md",
                      "iM", "vN", "mK", "iN", "i", "di", "vP",
                      "iS", "iN", "v", "P", "iM", "vN", "i", "di"];
          abgd.es = abgd.__es.slice(start, abgd.base_length).reverse();
          /////////////////////////////////////////////////////////////////
          abgd.__rv = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
                      20, 30, 40, 50, 60, 70, 80, 90,
                      100, 200, 300, 400, 500, 600, 700, 800, 900];
          abgd.rv = abgd.__rv.slice(start, abgd.base_length);
        })();

        abgd.root_lat = function(index) {
          if (index > -1 && index < abgd.base_length)
            return abgd.rs[index]
          else
            return false;
        };

        abgd.root_heb = function(index) {
          if (index > -1 && index < abgd.base_length)
            return abgd.rl[index]
          else
            return false;
        };

        abgd.endg_lat = function(index) {
          if (index > -1 && index < abgd.base_length)
            return abgd.es[index]
          else
            return false;
        };

        abgd.endg_heb = function(index) {
          let e0;
          if (index > -1 && index < abgd.base_length)
            e0 = abgd.es[index]; //get the ending itself in latin
          else
            return false;
          let e1 = e0.split(""); //split into letters
          for (let i=0;i<e1.length;i++) { //get each letter from hebrew list
            let ndx = abgd.__rs.indexOf(e1[i]); //by latin index
            if (ndx >= 0)
              e1[i] = abgd.__rl[ndx]
            else return false;
          }
          let e2 = e1.join("");
          return e2;
        };

        abgd.lval_lat = function (letter) {
          let ndx = abgd.__rs.indexOf(letter);
          if (ndx >= 0) {
            return parseInt(abgd.__rv[ndx]);
          } else return false;
        };

        abgd.lval_heb = function (letter) {
          let ndx = abgd.__rl.indexOf(letter);
          if (ndx >= 0) {
            return parseInt(abgd.__rv[ndx]);
          } else return false;
        };

        abgd.word_gem = function (word) {
          let wd0 = word.split("");
          let ar = abgd.__rl;
          if (ar.indexOf(wd0[0])==-1) //function thinks, that if the first word is latin, the word is in latin
            ar = abgd.__rs;
          let val = 0;
          for (let i=0;i<wd0.length;i++) {
            let ndx = ar.indexOf(wd0[i]);
            if (ndx >= 0) {
              val += parseInt(abgd.__rv[ndx]);
            } //if the letter not found, just add nothing
          }
          return val;
        };

        abgd.pair_lat = function (a, t) {
          let ret = "";
          if ((a >= 0 && t >= 0) && (a < abgd.base_length && t < abgd.base_length)) {
            ret = abgd.root_lat(a) + abgd.endg_lat(t);
          }
          return ret;
        };

        abgd.pair_heb = function (a, t) {
          let ret = "";
          if ((a >= 0 && t >= 0) && (a < abgd.base_length && t < abgd.base_length)) {
            ret = abgd.root_lat(a) + abgd.endg_lat(t);
          }
          return ret;
        };

        abgd.smod = function(num) {
          let path = 0, dir = 1;
          for (let i=0;i<num;i++) {
            if (path==abgd.base_length)
              dir = -1;
            if(path==0)
              dir = 1
            path += dir;
          }
          return path;
        };

        abgd.write = function(text, pos, obj) {
          //https://threejs.org/examples/css2d_label.html
          //https://github.com/mrdoob/three.js/blob/master/examples/webgl_loader_pdb.html
          //https://threejs.org/examples/#webgl_loader_pdb
          obj = obj || scene;
          var objDiv = document.createElement( 'div' );
          objDiv.className = 'label_' + M.Name(obj);
          objDiv.textContent = text;
          objDiv.style.marginTop = '-1em';
          objDiv.style.color = "rgb(255,0,0)";
          let objLabel = new THREE.CSS2DObject( objDiv );
          objLabel.position.copy(pos);
          scene.add( objLabel );
          return objLabel;
        };

        abgd.write_lat = function (i, j) {
          let pos = M.InSect(i, j);
          pos.y += 1;
          abgd.write(abgd.pair_lat(i, j), pos);
        };

        abgd.getMax = function () {
          if (abgd.maxGem != 0) return abgd.maxGem;
          let va = true, ndx=abgd.start, max=-1;
          while(va !== false) {
            if (ndx >= abgd.start+abgd.base_length)
              break;
            let w = abgd.endg_lat(ndx++);
            va = abgd.word_gem(w);
            if(va > max) max = va;
          }
          abgd.maxGem = max + abgd.__rv[abgd.base_length-1];
          return abgd.maxGem;
        }; abgd.getMax();

        abgd.getWordColor = function(word) { //word is not the word in itself, only the hebrew letters
          let wg = abgd.word_gem(word);
          let g = GradientGenerator.createGradient(abgd.gradient)
          let c = g.getColorHexAt(1/abgd.getMax()*wg);
          return c;
        };

        abgd.getGemColor = function (gem) {
          if (gem >= abgd.getMax()) return false;
          let g = GradientGenerator.createGradient(abgd.gradient)
          let c = g.getColorHexAt(1/abgd.getMax()*gem);
          return c;
        };
    };

    M.wyan_name = function (a, t) {
        return M.Name({"Wyan": [a, t]});
    };

    M.bBoxNCentroid = function (geo) {
        //https://github.com/mrdoob/three.js/issues/3471 — setFromObject
        let bb = new THREE.Box3();
        bb.setFromPoints(geo.geometry.vertices);
        geo.boundingBox = bb;
        geo.centroid = new THREE.Vector3();
        bb.getCenter(geo.centroid);
        [geo.centroid.z, geo.centroid.y] = [geo.centroid.y, geo.centroid.z];
    };

    M.f32x4ToV2 = function (f32a) {

        M.f32x4aToArray = function (f32) {
            var f32wda = [];
            for (let i=0;i<f32.length;i++) {
                for (let j=0;j<f32[i].length;j++) {
                    f32wda.push(f32[i][j]);}}
            return f32wda;
        };

        M.arr2V2 = function (arr) { //we skip Y-coord
            let ret = [];
            for(let i=0;i<arr.length;i+=3) {
                ret.push(new THREE.Vector2(arr[i], arr[i+2]));
            }
            return ret;
        };

        return M.arr2V2(M.f32x4aToArray(f32a))

    };

    M.wyan_points = function (path, onlyDots, inv) { //returns array of 4 Float32Arrays
        if(typeof(onlyDots)=='undefined') onlyDots=false;
        if(typeof(inv)=='undefined') inv=false;
        if (!M.path_extant_P(path)) return false;
        // console.log('wyan', path[0]);
        let wyan = [];
        for (let i=0;i<=path.length-1;i+=2) {
            if (i==path.length-1) {break}
            let a = path[i][0],
                t = path[i][1];
            let arr = [a, t];
            let pw = path[i+1]; //string representation of path step
            let pfr = pw.split("");
            let cwd = false; //clockwise direction

            //if T in the pair is not getting lower or A doesn't grow, we write CW
            if (pw == "-0" || pw == "0+") cwd = true;

            for (let c=0;c<pfr.length;c++) {
                if (pfr[c] == '+')
                    arr[c] += 1;
                else if (pfr[c] == '-')
                    arr[c] -= 1;
            }
            let d0 = M.InSect(a, t);
            let d1 = M.InSect(arr[0], arr[1]);
            let index = pfr.indexOf('0');
            let foci = [M.A, M.T];
            if (index > -1){

                let ar0 = M.IAngle(d0, foci[index]),
                    ar1 = M.IAngle(d1, foci[index]);

                let arc = M.EllArc(foci[index], hAxs=f(ar0.rad),
                            aS=ar0.angle, aE=ar1.angle, onlyDots,
                            undefined, undefined, inv, cwd, 0);

                wyan.push(arc);

            } else {
                let ln = M.Line(d0, d1, onlyDots, undefined, undefined, inv);
                wyan.push(ln);
            }
        }
        return wyan;
    };

    M.wyan_mesh = function (a, t, visible) {
        if (typeof(visible) == 'undefined')
            visible = true;
        /**
         * Функция для создания плоской фигуры по варианту пути на схеме.
         *   //https://threejs.org/docs/#api/en/extras/curves/CatmullRomCurve3
         *   //https://threejs.org/docs/#api/en/geometries/ParametricGeometry MAYBE?
         *   //https://threejs.org/docs/#api/en/extras/curves/SplineCurve
         *   //https://threejs.org/examples/#webgl_geometry_shapes
         *   //https://threejs.org/docs/#api/en/geometries/ExtrudeGeometry
         *   //http://qaru.site/questions/15388378/how-can-i-convert-a-threecatmullromcurve3-to-a-mesh
         */
        // let w = M.draw_wyan(a, t, true);
        let w = M.wyan_points(M.path(a, t), onlyDots=true);
        if (!w) return false;
        let pts = M.f32x4ToV2(w);
        let shp = new THREE.Shape();
        shp.moveTo(pts[0].x, pts[0].y);
        shp.autoClose = true;
        for (let i=1;i<pts.length;i++) {
            shp.lineTo(pts[i].x, pts[i].y);
        }
        let gep = new THREE.ExtrudeGeometry(
            shp,
            {
            steps: 2,
            depth: 2,
            bevelEnabled: true,
            bevelThickness: .1,
            bevelSize: .1,
            bevelSegments: 1
            });
        let emat = new THREE.MeshPhongMaterial( {
            color: abgd.getWordColor(abgd.pair_lat(a, t)), //0x2194ce,
            // emissive: abgd.getWordColor(abgd.pair_lat(a, t)), //0x2194ce,//M.getRandomColor(),// 0x642a2a,
            // specular: 0x6f8be6,
            // wireframe: true,
            transparent: true,
            opacity: .31,
            flatShading:true,
            side:THREE.DoubleSide, //THREE.DoubleSide, THREE.BackSide
        } );
        let mesh = new THREE.Mesh(gep, emat);
        mesh.rotation.x = -math.pi / 2;
        mesh.name = M.wyan_name(a, t);
        if (visible)
            scene.add(mesh);
        return mesh;
    };
};

(Test = () => {
    MAIN();
    dbmInit(1000, 11);//2,2);
    fnGeom();
    fnGroup();
    M.Dot(M.A, rad=M.DotSize, col='black');
    M.Dot(M.T, rad=M.DotSize, col='white');
    M.Dot(M.O, rad=M.DotSize, col='green')
    M.Na = 26;
    M.AddHebLang(0, M.X1);
    let setBaseCentroidAndCircle, circle, gcircles;
    if(true){
        
        let mkx = 0, mky = M.YS, mkz = M.I * math.sin(math.unit(60, "deg"));
        M.K = M.V([mkx, mky, mkz]);
        M.Dot(M.K, rad=M.DotSize, col='blue');

        // M.K2 = M.InSect(M.X1-1, M.X1-1);
        // M.Dot(M.K2, rad=M.DotSize, col='yellow');

        setBaseCentroidAndCircle = () => {
            //https://ru.wikipedia.org/wiki/Описанная_окружность

            let h = M.I / 3 * 2 * math.sin(math.unit(30, "deg"));
            M.InvFocus = M.V([M.O.x, M.O.y, M.O.z + h]);
            M.InvRadius = M.I * math.sqrt(3) / 3;
            // M.InvRadius = M.InvFocus.distanceTo(M.A);
            M.Dot(M.InvFocus, M.DotSize, col='red', true);

            let lcol = M.getRandomColor();
            M.Line(M.InvFocus, M.A, false, col=lcol);

            lcol = M.getRandomColor();
            M.Line(M.K, M.A, false, col=lcol);
            M.Line(M.K, M.T, false, col=lcol);
            M.Line(M.A, M.T, false, col=lcol);

            M.Circle(M.InvFocus, M.InvRadius);
        };

        circle = (r, f, inv, noSub, cl) => {
            if (typeof(r) == 'undefined') throw("circle without radius!");
            f = f || M.O;
            if(typeof(inv) == 'undefined') inv=false;
            if(typeof(noSub) == 'undefined') noSub=true;
            let cf = M.Circle(f, r, inv, cl);

            if(!noSub){
                let angle = math.PI * (f.x >= 0. ?1 :2) / 3;
                let fxo = r*math.cos(angle);
                let fzo = r*math.sin(angle);
                let wf = M.V([f.x+fxo, f.y, f.z+fzo]);
                let fn = (f.x >= 0.) ?'T' :'A';
                abgd.write(fn + math.floor(r/M.Mok1), wf, cf);
            }
            if (inv) M.Circle(f, r, inv=true, cl);
        };

        gcircles = (a, t, inv, cl) => {
            if(typeof(inv) == 'undefined') inv=false;
            if(inv) {
                // circle(a*M.Mok1, M.A, true);
                // circle(t*M.Mok1, M.T, true);
                // circle((a-1)*M.Mok1, M.A, true);
                circle((t-1)*M.Mok1, M.T, true, cl);
            } else {
                circle(a*M.Mok1, M.A, inv, cl);
                circle(t*M.Mok1, M.T, inv, cl);
                circle((a-1)*M.Mok1, M.A, inv, cl);
                circle((t-1)*M.Mok1, M.T, inv, cl);
            }
        };
    }
    // setBaseCentroidAndCircle ();
    // M.Circle(M.A, (M.X1-1)*M.Mok1);
    // M.Circle(M.T, (M.X1-1)*M.Mok1);

    // let counter = 0;
    for (let i=0;i<M.X2;i++) {
        for(let j=0;j<M.X2;j++) {
            let where = M.V([0, M.YS, 0]);
            let dot = M.InSect(i, j);
            if (dot) {
                where = dot;
                if (M.path_extant_P(M.path(i, j))) { //mark on wyan "centroid"
                    // M.wyan_mesh(i, j);
                    // M.draw_wyan(i, j);
                    // M.mark_wyan_dots(i, j);
                    gcircles(i, j, false, 'black');
                    let fw = M.wyan_mesh(i, j);
                    if (!fw)
                      continue;

                    M.bBoxNCentroid(fw);
                    where = fw.centroid;

                } else { //A or T - write on dot

                    if (i==0) where = M.A;
                    else if (j==0) where = M.T;
                    else {}
                }

                (function SubscribeWyansOrFoci () {
                    where.z = -where.z;
                    let val = abgd.pair_lat(i, j);
                    let str = val; //i+":"+j+":"+
                    // let str = `${i}:${j}|${counter}`;

                    let dname =
                    M.Dot(where, rad=M.DotSize*2, col=abgd.getWordColor(val)); //col=abgd.getWordColor(str));
                    let dobj = M.Obj[dname].object;

                    where.y += 10;
                    let pwh = M.V([0, M.YS, 0]); pwh.copy(where); pwh.y += 10;
                    // console.log(`${i}:${j} set to `, pwh);
                    abgd.write(str, where, dobj);
                    // counter++;
                });//();

                //Now put dots from inversion
                (function putInverseDot () {
                    let idot = M.Inverse(dot, M.O, M.I);
                    M.Dot(idot, rad=M.DotSize*4, col=abgd.getWordColor(abgd.pair_lat(i, j)), visible=true);
                    // M.Dot(idot, rad=M.DotSize, col='black');
                });//();
            } //else console.log(`unEx: ${i}:${j}`);
        }
    }
    // }

})();
