class tests {
    /*   method () {
           for (let i=0;i<dbm.X2;i++) {
               for (let j=0;j<dbm.X2;j++) {
                   if (i+j==dbm.X1-1) {
                   let dot = dbm.intersection(i, j)
                   if (dot)
                       D(i, j)}
               }
           }
           
           dbm.Draw = false
           let dwv = dbm.wyan_vecs(cSIZE/2, cSIZE/2)
           dbm.Draw = true
           let dwm = dbm.mesh(dwv, color='black')
           let dwmr = dbm.mesh_reflect(dwm) //reflection
           
           let gn = "TPart"
           dbm.arrayToGroup(SS, gn)
           let obj = dbm.Groups[gn]
           obj.rotateX(Math.PI/2)
           
       }*/
   
       static test () {
           window.cSIZE = 3
           window.dbm = new WDbm(new THREE.Vector3(500,0,0), cSIZE, 0); 
           window.CamPosSet = (v=[0,0,0]) => {dbm.WG.camera.position.set(v[0], v[1], v[2])}
           window.D = (a, t, clr="goldenrod") => dbm.dot(dbm.intersection(a, t), dbm.DotSize, clr) 
           window.I = (a, t) => dbm.intersection (a, t)    // dbm.mark_foci(); dbm.mark_circles_all(true);dbm.dot(dbm.O, dbm.DotSize, "goldenrod"); D(dbm.X2-1, dbm.X2-1)    // let wxr = new WXog3DWrite(156);     // BUG: DEBUG IT нахуй {let wds = new WDbmSymbols(wxr.C.cWAE_VAL, 0, cSIZE)}
       
   }}
   



if (false) {
    let dbm = new WDbm(new THREE.Vector3(500,0,0), 4, 2); dbm.mark_foci(); // dbm.WG.infiniteGrid(); dbm.WG.Grids['infiniteGrid'].position.y -= 100;
    let xoggwriter = new WXog3DWrite(156)  // let r1 = xoggwriter.write_semya_cyr ("ыме еох");
    /** *****************************************************************  **  *****************************************************************  **  ***************************************************************** **/
    if (false){
        function geomtest0 () {
            let ln = 500
            let a0 = dbm.V([ln*Math.cos(dbm.rads(60)), 0, ln*Math.sin(dbm.rads(60))])
            let a1 = dbm.angle(a0, dbm.O)
            dbm.dot(a0, dbm.DotSize*1.5, 'darkgoldenrod')
            dbm.vectorHelper(a0, length=ln)
            CL(`Angle: ${dbm.degs(a1.angle)}`)
            CL(a0)
            let a01 = dbm.fromCyl(a1.rad, a1.angle)
            dbm.dot(a01, dbm.DotSize*1.5, 'darkblue')
            dbm.vectorHelper(a01, length=ln)
            CL (a01) //(`New vec is ${a01.x}|${a01.y}|${a01.z}`)
        }
        function geomtest1() {
            dbm.mark_circles4wyan(3, 2)
            // dbm.mark_circles_all()
            let w0 = dbm.wyan_vecs(3, 2)
            // let m0 = dbm.mesh(w0)
            let d00 = dbm.intersection(3, 2)
            dbm.dot(d00, dbm.DotSize*2, "red")
            let d01 = dbm.intersection(3, 3)
            dbm.dot(d01, dbm.DotSize*2, "goldenrod")
        }

        function geomtest2() {
            dbm.mark_circles_all()
            for(let i=0;i<dbm.X2;i++){
                for(let j=0;j<dbm.X2;j++){
                    let p = dbm.wyan_path(i, j)
                    if (dbm.wyan_pathExists(p)) {
                        dbm.Draw = false
                        let wv0 = dbm.wyan_vecs(i, j)
                        dbm.Draw = true
                        let wm0 = dbm.mesh(wv0)
                    }
                }
            }
        }
        // dbm.mark_circles_all()

        // dbm.Draw = false
        // let gnam = dbm.wyan_vecs(3, 3)
        // dbm.Draw = true
        // let wyanmesh = dbm.mesh(gnam)
        dbm.mark_circles_all()
        for(let i=0;i<dbm.X2;i++){
            for(let j=0;j<dbm.X2;j++){
                let p = dbm.wyan_path(i, j)
                if (dbm.wyan_pathExists(p)) {
                    dbm.Draw = false
                    let wv0 = dbm.wyan_vecs(i, j)
                    dbm.Draw = true
                    let wm0 = dbm.mesh(wv0)
                }
            }
        }

        //CURRENT ON WORK
        let x = new WXog3DWrite(156)
        x.write_semya(x._2153())
        let w = new WDbmSymbols(x.C.cWAE_XOG, 0, 4)
        CL(w.word_value(x._1708()))
    }
    }