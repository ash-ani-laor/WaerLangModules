//https://github.com/stemkoski/stemkoski.github.com/tree/master/Three.js
//https://github.com/stemkoski/stemkoski.github.com/tree/master/Three.js/images
//https://stemkoski.github.io/Three.js/
//https://github.com/mrdoob/three.js/

var scene, camera, renderer, axesHelper, OrbitControls, resizer;
var light, lightbulb, parameters, sphere, cube, sph1, sph2;

function posSetEqual(obj1, obj2) {
    obj1.position.set(obj2.position.x, obj2.position.y, obj2.position.z);
}
(function(){
    (function basicSetup() {
        scene = new THREE.Scene();
        camera = new THREE.PerspectiveCamera( 45, window.innerWidth/window.innerHeight, 0.1, 10000 );
        renderer = new THREE.WebGLRenderer();
        axesHelper = new THREE.AxesHelper(100);
        OrbitControls = new THREE.OrbitControls(camera);
        renderer.setSize( window.innerWidth, window.innerHeight );
        resizer = new THREEx.WindowResize( renderer, camera );
        document.body.appendChild( renderer.domElement );
        camera.position.set(1.076402884249113, 41.69813739606645, 77.48368109322074);
        scene.add( axesHelper );
    })();
    (function grids(){
        //GRID
        var gridXZ = new THREE.GridHelper(50, 10, colorCenterLine=new THREE.Color(0x006600), colorGrid=new THREE.Color(0x006600));
        gridXZ.position.set( 25,-15,25 );
        scene.add(gridXZ);
        var gridXY = new THREE.GridHelper(50, 10, colorCenterLine=new THREE.Color(0x000066), colorGrid=new THREE.Color(0x000066));
        gridXY.position.set( 25,25,-15 );
        gridXY.rotation.x = Math.PI/2;
        scene.add(gridXY);
        var gridYZ = new THREE.GridHelper(50, 10, colorCenterLine=new THREE.Color(0x660000), colorGrid=new THREE.Color(0x660000));
        gridYZ.position.set( -15,25,25 );
        gridYZ.rotation.z = Math.PI/2;
        scene.add(gridYZ);
    })();
    (function skybox(){
        // SKYBOX
        var skyBoxGeometry = new THREE.BoxGeometry( 2000, 2000, 2000 );
        var skyBoxMaterial = new THREE.MeshBasicMaterial( { color: 0xaaaaaa, side: THREE.BackSide } );
        var skyBox = new THREE.Mesh( skyBoxGeometry, skyBoxMaterial );
        scene.add(skyBox);
        ////////EITHER SKYBOX OR FOG
        //FOG
        // scene.fog = new THREE.FogExp2( 0x335566, 0.01);//0.00025 );
    })();
    (function lightSetup(){
        // general light
        var ambientLight = new THREE.AmbientLight(0xffffff);
        scene.add(ambientLight);
        // light to see some volume
        light = new THREE.PointLight(0xffff00);
        light.position.set(-20,15,-3);
        scene.add(light);
        //lightbulb
        var lightbulbGeometry = new THREE.SphereGeometry( 3, 8, 8 );
        var lightbulbMaterial = new THREE.MeshBasicMaterial( { color: 0xffffff, transparent: true,  opacity: 0.9, blending: THREE.AdditiveBlending } );
        var wireMaterial = new THREE.MeshBasicMaterial( { color: 0x000000, wireframe: true } );
        var materialArray = [lightbulbMaterial, wireMaterial];
        lightbulb = THREE.SceneUtils.createMultiMaterialObject( lightbulbGeometry, materialArray );
        posSetEqual(lightbulb, light);
        scene.add(lightbulb);
    })();
    (function baseSetup(){
        //BASE
        planeGeo = new THREE.PlaneGeometry(32,32);
        planeMat = new THREE.MeshBasicMaterial({color:0xbbbbbb, opacity:.8, transparent: true});
        basePlane = new THREE.Mesh(planeGeo, planeMat);
        basePlane.rotation.x = -Math.PI / 2;
        basePlane.position.set(9,-5,9);
        basePlane.base = true;
        scene.add(basePlane);
        // OR
        // var floorTexture = new THREE.TextureLoader().load( 'img/checkerboard.jpg' );
        // floorTexture.wrapS = floorTexture.wrapT = THREE.RepeatWrapping;
        // //TODO: SOLVE What the shit prohibits rendering
        // floorTexture.repeat.set( 100, 100 );
        // var floorMaterial = new THREE.MeshBasicMaterial( { map: floorTexture, side: THREE.DoubleSide} );//, opacity:.8, transparent: true } );
        // var floorGeometry = new THREE.PlaneGeometry(1000, 1000, 10, 10);
        // var floor = new THREE.Mesh(floorGeometry, floorMaterial);
        // floor.position.y = -10;
        // floor.rotation.x = Math.PI / 2;
        // scene.add(floor);
    })();
})();
//#####################################################################################
//#####################################################################################
//#####################################################################################
//#####################################################################################
(function fnTestObjects(){
    (function oSphere(){
        // Sphere parameters: radius, segments along width, segments along height
        var sphereGeometry = new THREE.SphereGeometry( 10, 17, 17 );
        // use a "lambert" material rather than "basic" for realistic lighting.
        //   (don't forget to add (at least one) light!)
        var sphereMaterial = new THREE.MeshLambertMaterial( {color: 0x8888ff} );
        sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
        sphere.position.set(10, -1, +5);
        scene.add(sphere);
        //#####################################################################################
        //#####################################################################################
    })();
    (function oCube(){
        // Create an array of materials to be used in a cube, one for each side
        var cubeMaterialArray = [];
        // order to add materials: x+,x-,y+,y-,z+,z-
        cubeMaterialArray.push( new THREE.MeshBasicMaterial( { color: 0xff3333, wireframe:true} ) );
        cubeMaterialArray.push( new THREE.MeshBasicMaterial( { color: 0xff8800 } ) );
        cubeMaterialArray.push( new THREE.MeshBasicMaterial( { color: 0xffff33, wireframe:true } ) );
        cubeMaterialArray.push( new THREE.MeshBasicMaterial( { color: 0x33ff33 } ) );
        cubeMaterialArray.push( new THREE.MeshBasicMaterial( { color: 0x3333ff, wireframe:true } ) );
        cubeMaterialArray.push( new THREE.MeshBasicMaterial( { color: 0x8833ff } ) );
        // Cube parameters: width (x), height (y), depth (z),
        //        (optional) segments along x, segments along y, segments along z
        var cubeGeometry = new THREE.CubeGeometry( 10, 10, 10, 13, 11, 17 );
        // using THREE.MeshFaceMaterial() in the constructor below
        //   causes the mesh to use the materials stored in the geometry
        cube = new THREE.Mesh( cubeGeometry, cubeMaterialArray );
        cube.position.set(-6, 5, -5);
        scene.add( cube );
        //#####################################################################################
        //#####################################################################################
    })();
    (function oSph1(){
        //SPHERE WITH OUTLINE
        var sph1Geometry = new THREE.SphereGeometry( 7, 17, 17 );
        // use a "lambert" material rather than "basic" for realistic lighting.
        //   (don't forget to add (at least one) light!)
        var sph1Material = new THREE.MeshLambertMaterial( {color: 0x8888ff} );
        sph1 = new THREE.Mesh(sph1Geometry, sph1Material);
        sph1.position.set(50, -4, +5);
        scene.add(sph1);
        //////////////////////////////////////
        var outlineMaterial1 = new THREE.MeshBasicMaterial( { color: 0xff0000, side: THREE.BackSide } );
        var outlineMesh1 = new THREE.Mesh( sph1Geometry, outlineMaterial1 );
        posSetEqual(outlineMesh1, sph1)
        outlineMesh1.scale.multiplyScalar(1.05);
        scene.add( outlineMesh1 );
        //#####################################################################################
        //#####################################################################################
    })();
    (function oSph2(){
        var sph2Geometry = new THREE.SphereGeometry( 7, 17, 17 );
        // use a "lambert" material rather than "basic" for realistic lighting.
        //   (don't forget to add (at least one) light!)
        var sph2Material = new THREE.MeshLambertMaterial( {color: 0x8888ff} );
        sph2 = new THREE.Mesh(sph1Geometry, sph2Material);
        sph2.position.set(30, -4, +25);
        scene.add(sph2);
        (function applyShader0(){
            var noiseTexture = new THREE.ImageUtils.loadTexture( 'img/cloud.png' );
            noiseTexture.wrapS = noiseTexture.wrapT = THREE.RepeatWrapping;

            var lavaTexture = new THREE.ImageUtils.loadTexture( 'img/lava.jpg' );
            lavaTexture.wrapS = lavaTexture.wrapT = THREE.RepeatWrapping;

            // use "this." to create global object
            this.customUniforms = {
                baseTexture: 	{ type: "t", value: lavaTexture },
                baseSpeed: 		{ type: "f", value: 0.05 },
                noiseTexture: 	{ type: "t", value: noiseTexture },
                noiseScale:		{ type: "f", value: 0.5337 },
                alpha: 			{ type: "f", value: 1.0 },
                time: 			{ type: "f", value: 1.0 }
            };

            // create custom material from the shader code above
            //   that is within specially labeled script tags
            var customMaterial = new THREE.ShaderMaterial(
            {
                uniforms: customUniforms,
                vertexShader:   document.getElementById( 'vertexShader'   ).textContent,
                fragmentShader: document.getElementById( 'fragmentShader' ).textContent
            }   );
            // other material properties
            customMaterial.side = THREE.DoubleSide;
            // apply the material to a surface
            var flatGeometry = new THREE.PlaneGeometry( 100, 100 );
            var surface = new THREE.Mesh( flatGeometry, customMaterial );
            surface.position.set(-60,50,150);
            scene.add( surface );

            /////////////////////////////////
            // again, but for water!

            var waterTexture = new THREE.ImageUtils.loadTexture( 'img/water.jpg' );
            waterTexture.wrapS = waterTexture.wrapT = THREE.RepeatWrapping;

            // use "this." to create global object
            this.customUniforms2 = {
                baseTexture: 	{ type: "t", value: waterTexture },
                baseSpeed: 		{ type: "f", value: 1.15 },
                noiseTexture: 	{ type: "t", value: noiseTexture },
                noiseScale:		{ type: "f", value: 0.2 },
                alpha: 			{ type: "f", value: 0.8 },
                time: 			{ type: "f", value: 1.0 }
            };
            // create custom material from the shader code above
            //   that is within specially labeled script tags
            var customMaterial2 = new THREE.ShaderMaterial(
            {
                uniforms: customUniforms2,
                vertexShader:   document.getElementById( 'vertexShader'   ).textContent,
                fragmentShader: document.getElementById( 'fragmentShader' ).textContent
            }   );

            // other material properties
            customMaterial2.side = THREE.DoubleSide;
            customMaterial2.transparent = true;

            // apply the material to a surface
            var flatGeometry = new THREE.PlaneGeometry( 100, 100 );
            var surface = new THREE.Mesh( flatGeometry, customMaterial2 );
            surface.position.set(60,50,150);
            scene.add( surface );
        })();
        //#####################################################################################
        //#####################################################################################
    })();
})();
//#####################################################################################
//#####################################################################################
(function guiSetup() {
    //GUI SETUP
	gui = new dat.GUI();
	parameters =
	{
		x: 17, y: 9, z: 17,
		color:  "#ff0000", // color (change "#" to "0x")
		colorA: "#000000", // color (change "#" to "0x")
		colorE: "#000033", // color (change "#" to "0x")
		colorS: "#ffff00", // color (change "#" to "0x")
        shininess: 30,
		opacity: .65,
		visible: true,
		material: "Phong",
		reset: function() { resetSphere() }
	};

	var folder1 = gui.addFolder('Position');
	var sphereX = folder1.add( parameters, 'x' ).min(-200).max(200).step(1).listen();
	var sphereY = folder1.add( parameters, 'y' ).min(0).max(100).step(1).listen();
	var sphereZ = folder1.add( parameters, 'z' ).min(-200).max(200).step(1).listen();
	folder1.open();

	sphereX.onChange(function(value)
	{   sphere.position.x = value;   });
	sphereY.onChange(function(value)
	{   sphere.position.y = value;   });
	sphereZ.onChange(function(value)
	{   sphere.position.z = value;   });

	var sphereColor = gui.addColor( parameters, 'color' ).name('Color (Diffuse)').listen();
	sphereColor.onChange(function(value) // onFinishChange
	{   sphere.material.color.setHex( value.replace("#", "0x") );   });
	var sphereColorA = gui.addColor( parameters, 'colorA' ).name('Color (Ambient)').listen();
	sphereColorA.onChange(function(value) // onFinishChange
	{   sphere.material.ambient.setHex( value.replace("#", "0x") );   });
	var sphereColorE = gui.addColor( parameters, 'colorE' ).name('Color (Emissive)').listen();
	sphereColorE.onChange(function(value) // onFinishChange
	{   sphere.material.emissive.setHex( value.replace("#", "0x") );   });
	var sphereColorS = gui.addColor( parameters, 'colorS' ).name('Color (Specular)').listen();
	sphereColorS.onChange(function(value) // onFinishChange
	{   sphere.material.specular.setHex( value.replace("#", "0x") );   });
	var sphereShininess = gui.add( parameters, 'shininess' ).min(0).max(60).step(1).name('Shininess').listen();
	sphereShininess.onChange(function(value)
	{   sphere.material.shininess = value;   });
	var sphereOpacity = gui.add( parameters, 'opacity' ).min(0).max(1).step(0.01).name('Opacity').listen();
	sphereOpacity.onChange(function(value)
	{   sphere.material.opacity = value;   });

	var sphereMaterial = gui.add( parameters, 'material', [ "Basic", "Lambert", "Phong", "Wireframe" ] ).name('Material Type').listen();
	sphereMaterial.onChange(function(value)
	{   updateSphere();   });

	gui.add( parameters, 'reset' ).name("Reset Sphere Parameters");

    gui.open();
    updateSphere()

    function updateSphere() {
        var value = parameters.material;
        var newMaterial;
        if (value == "Basic")
            newMaterial = new THREE.MeshBasicMaterial( { color: 0x000000 } );
        else if (value == "Lambert")
            newMaterial = new THREE.MeshLambertMaterial( { color: 0x000000 } );
        else if (value == "Phong")
            newMaterial = new THREE.MeshPhongMaterial( { color: 0x000000 } );
        else // (value == "Wireframe")
            newMaterial = new THREE.MeshBasicMaterial( { wireframe: true } );
        sphere.material = newMaterial;

        sphere.position.x = parameters.x;
        sphere.position.y = parameters.y;
        sphere.position.z = parameters.z;
        sphere.material.color.setHex( parameters.color.replace("#", "0x") );
        if (sphere.material.ambient)
            sphere.material.ambient.setHex( parameters.colorA.replace("#", "0x") );
        if (sphere.material.emissive)
            sphere.material.emissive.setHex( parameters.colorE.replace("#", "0x") );
        if (sphere.material.specular)
            sphere.material.specular.setHex( parameters.colorS.replace("#", "0x") );
        if (sphere.material.shininess)
            sphere.material.shininess = parameters.shininess;
        sphere.material.opacity = parameters.opacity;
        sphere.material.transparent = true;
    }
    function resetSphere() {
        parameters.x = 0;
        parameters.y = 30;
        parameters.z = 0;
        parameters.color = "#ff0000";
        parameters.colorA = "#000000";
        parameters.colorE = "#000033";
        parameters.colorS = "#ffff00";
        parameters.shininess = 30;
        parameters.opacity = 1;
        parameters.visible = true;
        parameters.material = "Phong";
        updateSphere();
    }
});//();
//#####################################################################################
//#####################################################################################
    function animate () {
    requestAnimationFrame( animate );

    OrbitControls.update();

    renderer.render( scene, camera );
}; animate();
