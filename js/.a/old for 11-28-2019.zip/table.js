//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

fnTable = function (){
  M.T = function (Width, N, Start) {
    (M.T.Init = function (){
      let _ = M.T;
      _.Cells = {};
    })();
    Width = Width || 5;
    Start = Start || -150;
    let Depth = -20
    let tul = M._V([Start,           Depth,   Width*N]), //where 10 is the width and height of the cell
        tur = M._V([Start + Width*N, Depth,   Width*N]),
        tlr = M._V([Start + Width*N, Depth,   0      ]),
        tll = M._V([Start,           Depth,   0      ]);
    M._Line(tul, tur);
    M._Line(tur, tlr);
    M._Line(tlr, tll);
    M._Line(tll, tul);
    for (let i=1;i<N; i++) {
      let spz = M._V([Start + Width * i, Depth, Width*N]), epz = M._V([Start + Width * i, Depth, 0]);
      let spx = M._V([Start, Depth, Width*i]), epx = M._V([Start + Width * N, Depth, Width*i]);
      M._Line (spz, epz, false, G._getRandomColor());
      M._Line (spx, epx, false, G._getRandomColor());
    }
  }; //M.T(5, 22, -200);

  M.T.TbyCells = function (Width, N, vSt) {
    let s = M._V([vSt.x, vSt.y, vSt.z])
    for(let row=0;row<N;row++) {
      for(let cel=0;cel<N;cel++) {
        let pul = M._V([s.x,          s.y, s.z]);
        let pur = M._V([s.x + Width,  s.y, s.z]);
        let plr = M._V([s.x + Width,  s.y, s.z + Width]);
        let pll = M._V([s.x,          s.y, s.z + Width]);
        M._Line(tul, tur);
        M._Line(tur, tlr);
        M._Line(tlr, tll);
        M._Line(tll, tul);
      }
    }
  }
};
