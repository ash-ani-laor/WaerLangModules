let spr = makeTextSprite(text);
    spr.position.set(pos.x, pos.y, pos.z);
    scene.add(spr);
    // let loader = new THREE.FontLoader();
    // let font = loader.load ("fonts/optimer_bold.typeface.json", 
    //   function (font) {
    //     // scene.add(font)
    //     let tgeo = new THREE.TextGeometry(text, {
    //       font: font,
    //       size: 1,
    //       height: .001,
    //       curveSegments: 9,
    //       // bevelEnabled: true,
    //       // bevelThickness: .1,
    //       // bevelSize: .1,
    //       // bevelOffset: 0,
    //       // bevelSegments: 1
    //     });
    //     let tmat = new THREE.MeshPhongMaterial({
    //       color:0xff0000//abgd.getWordColor()
    //     });
    //     let tmes = new THREE.Mesh(tgeo, tmat);
    //     tmes.position.set(pos.x, pos.y, pos.z);
    //     tmes.rotation.x = Math.PI / 3;
    //     tmes.rotation.y = Math.PI;// + Math.PI / 4;
    //     scene.add(tmes);
    // },
    // function (xhr) {},
    // function (err) {console.log(err)});




(function css3d_ver1(){
    var vidElement = function ( src, x, y, z, ry ) {
        var div = document.createElement( 'div' );
        div.style.width = '240px';
        div.style.height = '180px';
        div.style.backgroundColor = '#000';
        var iframe = document.createElement( 'iframe' );
        iframe.style.width = '240px';
        iframe.style.height = '180px';
        iframe.style.border = '0px';
        // iframe.src = [ 'https://www.youtube.com/embed/', id, '?rel=0' ].join( '' );
        iframe.src = src;
        div.appendChild( iframe );
        var object = new THREE.CSS3DObject( div );
        object.position.set( x, y, z );
        object.rotation.y = ry;
        return object;
    };
    vidElement ("/waap/", -100, 0, 0, 0);
    /**
     * https://threejs.org/examples/#css3d_youtube
     * https://github.com/mrdoob/three.js/blob/master/examples/css3d_youtube.html
     */
})//();

(function css3d_ver0(){
    var planeMaterial   = new THREE.MeshBasicMaterial({color: 0x000000, opacity: 0.1, side: THREE.DoubleSide });
    var planeWidth = 360;
    var planeHeight = 120;
    var planeGeometry = new THREE.PlaneGeometry( planeWidth, planeHeight );
    var planeMesh= new THREE.Mesh( planeGeometry, planeMaterial );
    planeMesh.position.y += planeHeight/2;
    // add it to the standard (WebGL) scene
    scene.add(planeMesh);
    
    // create a new scene to hold CSS
    cssScene = new THREE.Scene();
    // create the iframe to contain webpage
    var element	= document.createElement('iframe')
    // webpage to be loaded into iframe
    element.src	= "http://localhost:8001/waa";
    // width of iframe in pixels
    var elementWidth = 1024;
    // force iframe to have same relative dimensions as planeGeometry
    var aspectRatio = planeHeight / planeWidth;
    var elementHeight = elementWidth * aspectRatio;
    element.style.width  = elementWidth + "px";
    element.style.height = elementHeight + "px";
    
    // create a CSS3DObject to display element
    var cssObject = new THREE.CSS3DObject( element );
    // synchronize cssObject position/rotation with planeMesh position/rotation 
    cssObject.position = planeMesh.position;
    cssObject.rotation = planeMesh.rotation;
    // resize cssObject to same size as planeMesh (plus a border)
    var percentBorder = 0.05;
    cssObject.scale.x /= (1 + percentBorder) * (elementWidth / planeWidth);
    cssObject.scale.y /= (1 + percentBorder) * (elementWidth / planeWidth);
    cssScene.add(cssObject);
    
    // create a renderer for CSS
    rendererCSS	= new THREE.CSS3DRenderer();
    rendererCSS.setSize( window.innerWidth, window.innerHeight );
    rendererCSS.domElement.style.position = 'absolute';
    rendererCSS.domElement.style.top	  = 0;
    rendererCSS.domElement.style.margin	  = 0;
    rendererCSS.domElement.style.padding  = 0;
    document.body.appendChild( rendererCSS.domElement );
    // when window resizes, also resize this renderer
    THREEx.WindowResize(rendererCSS, camera);

    renderer.domElement.style.position = 'absolute';
    renderer.domElement.style.top      = 0;
    // make sure original renderer appears on top of CSS renderer
    renderer.domElement.style.zIndex   = 1;
    rendererCSS.domElement.appendChild( renderer.domElement );
})();


geomtest = function () {
    let cube0_geom = new THREE.BoxGeometry( 1, 1, 1 );
    let cube0_mat = new THREE.MeshPhongMaterial( { color: 0x441188, vertexColors:THREE.VertexColors } );
    this.obj.cube0 = new THREE.Mesh( cube0_geom, cube0_mat );
    this.scene.add( this.obj.cube0 );
    //#####################################################################################
    //#####################################################################################
    var material = new THREE.LineBasicMaterial({
        color: 0x0000ff
    });
    var geometry = new THREE.Geometry();
    geometry.vertices.push(
        new THREE.Vector3( -3, 0, 0 ),
        new THREE.Vector3( 0, 3, 0 ),
        new THREE.Vector3( 3, 0, 0 )
    );
    var line = new THREE.Line( geometry, material );
    this.scene.add( line );
    //#####################################################################################
    //#####################################################################################
    var geometry = new THREE.RingGeometry( 2, 3, 6 );
    var material = new THREE.MeshBasicMaterial( { color: 0xffff00, side: THREE.DoubleSide } );
    var mesh = new THREE.Mesh( geometry, material );
    this.scene.add( mesh );
}
/*******************************************************************
 * *****************************************************************
 * dbm.js 2019-03-26 23:33:00
 */
/*
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/for...of
    https://nodejs.org/en/docs/guides/getting-started-guide/

    look at:
        https://threejs.org/examples/#webgl_buffergeometry_custom_attributes_particles
        https://threejs.org/examples/webgl_buffergeometry_points.html
        https://threejs.org/examples/?q=points#webgl_custom_attributes_points2
        https://github.com/mrdoob/three.js/blob/master/examples/webgl_custom_attributes_points3.html

        https://threejs.org/                           examples/webgl_interactive_buffergeometry.html
        https://github.com/mrdoob/three.js/blob/master/examples/webgl_interactive_buffergeometry.html
        https://github.com/mrdoob/three.js/blob/master/examples/webgl_interactive_cubes.html

        http://stemkoski.github.io/Three.js/index.html  â€” great and simple examples of usage

        http://poly.google.com

        https://whs.io/: https://whs-dev.surge.sh/examples/ + http://127.0.0.1:8000/whs/examples/basic/

*/
class video {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera( 75, window.innerWidth/window.innerHeight, 0.1, 1000 );
    renderer = new THREE.WebGLRenderer();
    axesHelper = new THREE.AxesHelper(10);
    OrbitControls = new THREE.OrbitControls(this.camera);
    obj = {}; //objects in class

    constructor () {
        this.renderer.setSize( window.innerWidth, window.innerHeight );
        document.body.appendChild( this.renderer.domElement );
        this.camera.position.set( 30.14523826042693, 17.934571240755755, 29.423819729086567 );
        // this.OrbitControls.update();
        this.scene.add( new THREE.HemisphereLight( 0xffffff, 0x080808, 3 ) )
        this.scene.add( this.axesHelper );
        this.resizer = new THREEx.WindowResize( this.renderer, this.camera );
    }

    geomtest = function (data) {
        //#####################################################################################
        //#####################################################################################
        // var material = new THREE.LineBasicMaterial({color: 0xffff00});
        var material = new THREE.PointsMaterial( { size: 0.1, color: 0xf29618 } );
        var geometry = new THREE.BufferGeometry();
        var poss = [];
        for (let vec of data) {
            poss.push( vec[0], vec[1], vec[2] );
        }
        geometry.addAttribute( 'position', new THREE.Float32BufferAttribute( poss, 3 ) )
        geometry.computeBoundingSphere();

        var pts = new THREE.Points( geometry, material );
        this.scene.add( pts );
        //#####################################################################################
        //#####################################################################################
    }

}

let v = new video();
var arr;
$(function(){

    const HOSTNAME = "http://localhost:8008/";
    $.ajax({
        url: HOSTNAME + "htbin/inn.py",
        type: "post",
        success: function(data, textStatus, jqXHR) {
            arr = JSON.parse(data);
            // console.log(arr);
            v.geomtest(arr);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown)
        }
    });

    let animate = function () {
        requestAnimationFrame( animate );

        v.OrbitControls.update();

        v.renderer.render( v.scene, v.camera );
    }; animate();
});
